from imports.general_imports import *
from imports.gates.allGates import *
from imports.circuit import *
from imports.combinational_logic.logic import *
from imports.combinational_logic.data_manipulative import *
from imports.combinational_logic.arithmetic import *
from sequential_logic.memory_elements import *
from sequential_logic.latches_ffs import *
from sequential_logic.counters import *
from sequential_logic.state_machines import *
from CPU.control_unit import *
from imports.clock import *
from CPU.counters import *
from time import time, sleep
from imports.MNEMONICS import *
import sys
import os


# function for automating the process of dumping op_codes in to system_memory
def dump_program(_op_codes):
    for address, _op_code in enumerate(_op_codes):
        system_memory.get_outputs(
            _op_code,
            word_generator(address),
            byte_generator(0x1D)
        )


op_codes = [
    LDAMA1H[:8] + byte_generator(0x00),
    LDAMA1L[:8] + byte_generator(0x0D),
    LDAA,
    LDAMA1H[:8] + byte_generator(0x00),
    LDAMA1L[:8] + byte_generator(0x0E),
    LDAB,
    LDAMA1H[:8] + byte_generator(0x00),
    LDAMA1L[:8] + byte_generator(0x0F),
    LDAD,
    ADD,  # 0x09 c = a + b
    TBA,  # a = b
    TCB,  # b = c
    JMP,  # goto 0x09
    word_generator(0x00),
    word_generator(0x01),
    word_generator(0x0009 - 1)  # always give 1 less than the required address, because PC
                                # will increment during next cycle
]
_op_codes = [
    LDAMA1H[:8] + byte_generator(0x00),
    LDAMA1L[:8] + byte_generator(0x07),
    LDAD,
    ADD,
    TBA,
    TCB,
    JMP,
    word_generator(0x0003 - 1)  # always give 1 less than the required address, because PC
                                # will increment during next cycle
]

dumping_time = time()
dump_program(op_codes)
print("dumping time : {}s".format(time() - dumping_time))

# start system clock
# clock = Clock(1000)

# initialize programme counter
program_counter = CPUCounter(65535)

# instantiate control_unit
control_unit = ControlUnit()


run_sim = True

# cpu_A_register.get_outputs(word_generator(0x00), byte_generator(0x01))
# cpu_B_register.get_outputs(word_generator(0x01), byte_generator(0x03))

for i in range(9):
    print("sys_mem {} : ".format(i), bin_list_to_hex(system_memory.get_outputs(
        zeros,
        word_generator(i),
        byte_generator(0x1C)
    )))
print()

screen_text = \
"""
fetching time : {op_time}s op_code : {op_code}
execution time : {exe_time}s
REG_A : {A} REG_B : {B}
REG_C : {C} REG_D : {D}
"""

screen_text_refresh_rate = 2
last_print_time = time()

while run_sim:
    op_code_fetching_time = time()
    # get clock state
    # current_clock_state = clock.get_output()

    # fetch op_code
    address_bus.get_output(
        cpu_program_counter_register.get_outputs(
            zeros,
            byte_generator(0x12)
        )
    )
    instruction_bus.get_output(
        system_memory.get_outputs(
            zeros,
            address_bus.get_bus_current_data(),
            byte_generator(0x1C)
        )
    )
    cpu_instruction_register.get_outputs(
        instruction_bus.get_bus_current_data(),
        byte_generator(0x15)
    )
    op_code = cpu_instruction_register.get_outputs(
        zeros,
        byte_generator(0x14)
    )
    op_code_fetching_time = time() - op_code_fetching_time

    # control_unit generates byte codes to control internal CPU devices based on op_code
    programme_execution_time = time()

    control_unit.main_loop(op_code)
    programme_execution_time = time() - programme_execution_time

    # increment program_counter
    program_counter.get_outputs()
    #if time() - last_print_time > 1.0/screen_text_refresh_rate:
    #    last_print_time = time()
    print(screen_text.format(
        op_time=op_code_fetching_time,
        op_code=op_code,
        exe_time=programme_execution_time,
        A=bin_list_to_hex(cpu_A_register.get_outputs(zeros, byte_generator(0x00))),
        B=bin_list_to_hex(cpu_B_register.get_outputs(zeros, byte_generator(0x02))),
        C=bin_list_to_hex(cpu_C_register.get_outputs(zeros, byte_generator(0x04))),
        D=bin_list_to_hex(cpu_D_register.get_outputs(zeros, byte_generator(0x06)))
    ))
        #sleep(1)
        #os.system("cls")

    # sys.stdout.write("\033[K")
    # run_sim = False


