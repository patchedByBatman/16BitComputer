# THE FOLLOWING OP_CODES EACH DEMONSTRATE A CERTAIN EXAMPLE


# FIBONACCI SERIES
op_codes = [
    LDAMA1H[:8] + byte_generator(0x00),
    LDAMA1L[:8] + byte_generator(0x08),
    LDAD,
    ADD,
    TBA,
    STAC,
    LDAB,
    JMP,
    word_generator(0x0003 - 1)  # always give 1 less than the required address, because PC
                                # will increment during next cycle
]

# JMP EXAMPLE
op_codes = [
    LDAMA1H[:8] + byte_generator(0x00),
    LDAMA1L[:8] + byte_generator(0x0A),
    LDAA,
    LDAB,
    LDAMA1H[:8] + byte_generator(0x00),
    LDAMA1L[:8] + byte_generator(0x0B),
    LDAD,
    ADD,
    TCA,
    JMP,
    word_generator(0x0002),
    word_generator(0x0007 - 1)  # always give 1 less than the required address, because PC
                                # will increment during next cycle
]

# JNZ EXAMPLE
op_codes = [
    LDAMA1H[:8] + byte_generator(0x00),
    LDAMA1L[:8] + byte_generator(0x0B),
    LDAA,
    LDAB,
    SUB,
    CMP,
    LDAMA1H[:8] + byte_generator(0x00),
    LDAMA1L[:8] + byte_generator(0x0C),
    LDAD,
    JNZ,
    HLT,
    word_generator(0x0002),
    word_generator(0x0001 - 1)  # always give 1 less than the required address, because PC
                                # will increment during next cycle
]
