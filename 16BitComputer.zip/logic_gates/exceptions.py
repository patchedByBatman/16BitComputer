class Exceptions:
    class TooManyInputsException(Exception):
        def __init__(self, given_num_inputs, gate_name, gate_input_limit):
            self.message = "the given no.of inputs (given:{given}) > selected {gate} gate input pins (limit:{limit})".format(given=given_num_inputs, gate=gate_name, limit=gate_input_limit)
            super().__init__(self.message)

    class NotBinaryDataException(Exception):
        def __init__(self, inputs):
            super().__init__("given inputs '{inputs}' is not BINARY".format(inputs=inputs))

    class BusDataCorrupt(Exception):
        def __init__(self, bus_label, bus_data):
            super().__init__("the DATA on BUS (LABEL : {label}) "
                             "is corrupt by multiple signals (with DATA : {data})"
                             .format(label=bus_label, data=bus_data))
