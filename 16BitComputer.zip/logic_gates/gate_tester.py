import numpy as np
import logic_gates.basic_logic_gates as blg
import logic_gates.universal_gates as ug
import logic_gates.special_gates as sg
from binary_data.binary import DATA


a = blg.AND()
o = blg.OR()
n = blg.NOT()
nand = ug.NAND()
nor = ug.NOR()
i = np.ones(5, dtype=np.int8)
i[2] = 0

binData = DATA(i)
xor = sg.XOR()
xnor = sg.XNOR()

print(i)
print(a.get_output(i))
print(o.get_output(i))
print(n.get_outputs(i))
print(nand.get_output(i))
print(nor.get_output(i))
print(~binData[1])

print(xor.get_output(i))
print(xnor.get_output(i))