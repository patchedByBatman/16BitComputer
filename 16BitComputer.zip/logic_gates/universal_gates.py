import logic_gates.basic_logic_gates as blg
from imports.gates.basic_gates import *


class NAND(blg.GATE):
    def __init__(self):
        super().__init__()

    def get_output(self, inputs):
        return not_gate.get_output(and_gate.get_output(inputs))


class NOR(blg.GATE):
    def __init__(self):
        super().__init__()

    def get_output(self, inputs):
        return not_gate.get_output(or_gate.get_output(inputs))
