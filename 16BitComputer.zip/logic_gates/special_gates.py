import logic_gates.basic_logic_gates as blg
from imports.gates.basic_gates import *
import numpy as np


class TwoBitXOR(blg.GATE):
    def __init__(self):
        super().__init__()

    def get_output(self, inputs):
        a = inputs[0]
        b = inputs[1]
        a_bar_b = and_gate.get_output([not_gate.get_output(a), b])
        a_b_bar = and_gate.get_output([a, not_gate.get_output(b)])
        return or_gate.get_output([a_bar_b, a_b_bar])


class XOR(blg.GATE):
    def __init__(self):
        super().__init__()
        self.xor_2bit = TwoBitXOR()

    def get_output(self, inputs):
        output = self.xor_2bit.get_output(inputs[:2])
        for bit in inputs[2:]:
            output = self.xor_2bit.get_output([output, bit])
        return output


class XNOR(blg.GATE):
    def __init__(self):
        super().__init__()
        self.xor_gate = XOR()

    def get_output(self, inputs):
        return not_gate.get_output(self.xor_gate.get_output(inputs))

