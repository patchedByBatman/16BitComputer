import numpy as np
from logic_gates.exceptions import Exceptions


class GATE:
    def __init__(self):
        pass

    def ip_data_check(self, inputs):  # check to see if given data is other than binary
        raise Exceptions.NotBinaryDataException(inputs)

    # overridable methods
    def get_outputs(self, *args):
        pass

    def get_output(self, *args):
        pass


class Transistor(GATE):
    def __init__(self, logic_supply_level):
        super().__init__()
        self.logic_supply_level = logic_supply_level

    def get_output(self, gate_voltage_level):
        if gate_voltage_level:
            return self.logic_supply_level
        return None



class AND(GATE):
    def __init__(self):
        super().__init__()

    def get_output(self, inputs):
        output = 1
        if inputs is None or None in inputs:
            return None
        for bit in inputs:
            output = bit & output
        return output


class OR(GATE):
    def __init__(self):
        super().__init__()

    def get_output(self, inputs):
        output = 0
        if inputs is None or None in inputs:
            return None
        for bit in inputs:
            output = bit | output
        return output


class NOT(GATE):
    def __init__(self):
        super().__init__()

    def get_outputs(self, inputs):
        if inputs is None:
            return [None]
        if type(inputs) is not int and None in inputs:
            return [None]*len(inputs)
        return [1 - _input for _input in inputs]

    def get_output(self, inputs):
        if inputs is None:
            return None
        return 1 - inputs
