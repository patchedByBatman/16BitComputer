import logic_gates.basic_logic_gates as blg
from imports.general_imports import *
from logic_gates.exceptions import Exceptions


class BIT:
    possible_values = {0, 1}

    def __init__(self, value):
        if value not in self.possible_values:
            raise Exceptions.NotBinaryDataException(value)
        self.value = value

    def __add__(self, other):
        return self.value | other.value

    def __mul__(self, other):
        return self.value & other.value

    def __invert__(self):
        return 1 - self.value


class DATA:
    def __init__(self, data):
        self.bits = np.array([BIT(bit) for bit in data], dtype=BIT)
        self.bits = self.bits.reshape(self.bits.size, 1)

    def __setitem__(self, key, value):
        self.bits[key] = value

    def __getitem__(self, item):
        return self.bits[item]

    def __add__(self, other):  # override to define OR operation
        output = np.zeros((self.bits.size, 1), dtype=BIT)
        for i, (aBit, bBit) in enumerate(zip(self.bits, other.bits)):
            output[i] = aBit + bBit
        return output

    def __mul__(self, other):
        output = np.zeros((self.bits.size, 1), dtype=BIT)
        for i, (aBit, bBit) in enumerate(zip(self.bits, other.bits)):
            output[i] = aBit * bBit
        return output

    def __invert__(self):
        output = np.zeros((self.bits.size, 1), dtype=BIT)
        for i, bit in enumerate(self.bits):
            output[i] = ~bit
        return output

