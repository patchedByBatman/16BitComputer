from combinational_circuits.arithmetic.subtractor import *


class WordDivider(Circuit):
    def __init__(self, device_id):
        super().__init__()
        self.word_subtractor_ckt = WordSubtractor(device_id)
        self.device_id = device_id

    def get_outputs(self, word_a, word_b):
        return [[None]*16, None]