from imports.gates.allGates import *
from imports.circuit import Circuit
from imports.general_imports import *
from combinational_circuits.arithmetic.adder import *


class WordSubtractor(Circuit):
    def __init__(self, device_id):
        super().__init__()
        self.word_adder_ckt = WordAdder(device_id)
        self.device_id = device_id

    def get_outputs(self, word_a, word_b):
        outputs = np.zeros(16, dtype=np.int8)
        op = self.word_adder_ckt.get_outputs(word_a, not_gate.get_outputs(word_b), 1)
        sign_bit = op[0][0]
        outputs = op[0] if op[0][0] == 0 else self.word_adder_ckt.get_outputs(np.zeros(16, np.int8), not_gate.get_outputs(op[0]), 1)[0]
        return outputs, sign_bit


