import numpy as np
from sequential_logic.memory_elements import *
from imports.gates.allGates import *
from imports.general_imports import *
from imports.circuit import Circuit


class HalfAdder(Circuit):
    def __init__(self):
        super().__init__()

    def get_outputs(self, inputs):
        return {'s': xor_gate.get_output(inputs), 'c': and_gate.get_output(inputs)}


class FullAdder(Circuit):
    def __init__(self):
        super().__init__()

    def get_outputs(self, inputs):
        c_in = inputs[2]
        a_xor_b = xor_gate.get_output(inputs[:2])
        a_and_b = and_gate.get_output(inputs[:2])
        a_xor_b__and_cin = and_gate.get_output(np.array([a_xor_b, c_in]))
        return {'s': xor_gate.get_output(inputs),
                'c': or_gate.get_output(np.array([a_xor_b__and_cin, a_and_b]))}


class WordAdder(Circuit):
    def __init__(self, device_id):
        super().__init__()
        self.full_adder_ckt = FullAdder()
        self.device_id = device_id

    def get_outputs(self, word_a, word_b, c_in):
        outputs = [None]*16
        for i, (bit1, bit2) in enumerate(zip(word_a[::-1], word_b[::-1])):
            op = self.full_adder_ckt.get_outputs(np.array([bit1, bit2, c_in]))
            outputs[i] = op['s']
            c_in = op['c']
        outputs = outputs[::-1]
        return outputs, c_in
