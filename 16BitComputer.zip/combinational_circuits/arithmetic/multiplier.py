from imports.general_imports import *
from combinational_circuits.arithmetic.adder import WordAdder
from imports.circuit import Circuit


class WordMultiplier(Circuit):
    def __init__(self, device_id):
        super().__init__()
        self.word_adder_ckt = WordAdder(device_id)
        self.device_id = device_id

    def get_outputs(self, word_a, word_b):
        outputs = np.zeros(32, dtype=np.int8)
        return [[None]*16, None]