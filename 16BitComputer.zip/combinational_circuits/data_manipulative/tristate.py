from imports.general_imports import *
from imports.gates.allGates import *
from imports.circuit import Circuit


class TriStateCell(Circuit):
    """
    en | output
    -----------
     0 |   hi_z
     1 | bit_in
    """
    def __init__(self):
        super().__init__()

    def get_output(self, bit_in, en):
        and_result = and_gate.get_output([bit_in, en])
        nor_result = nor_gate.get_output([bit_in, not_gate.get_output(en)])
        result1 = transistor_gate_high.get_output(and_result)
        result2 = transistor_gate_low.get_output(nor_result)
        result3 = {result1, result2} - {None}
        if not result3:
            return None
        return result3.pop()


class TriStateArray(Circuit):
    def __init__(self):
        super().__init__()
        self.__tri_state_cell_ckt = TriStateCell()

    def get_outputs(self, data_in, en):
        return [self.__tri_state_cell_ckt.get_output(bit_in, en) for bit_in in data_in]

