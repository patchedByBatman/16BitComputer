from imports.gates.allGates import *
from imports.circuit import Circuit
from imports.general_imports import *


class MuxBuilder(Circuit):
    def __init__(self, num_address_pins):
        super().__init__()
        self.num_address_pins = num_address_pins
        self.num_data_in = 2**self.num_address_pins
        self.selection_logic_data = [[int(j) for j in format(i, "0{}b".format(self.num_address_pins))] for i in range(self.num_data_in)]


class MUXNTo1(Circuit):
    def __init__(self, num_data_lines):
        super().__init__()
        self.num_data_lines = num_data_lines
        self.__mux_builder = MuxBuilder(num_data_lines)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        results = [and_gate.get_output([data_bit] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data)]
        return or_gate.get_output(results)


class MUX2To1(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = MuxBuilder(1)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        results = [and_gate.get_output([data_bit] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data)]
        return or_gate.get_output(results)


class MUX4To1(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = MuxBuilder(2)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        results = [and_gate.get_output([data_bit] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data)]
        return or_gate.get_output(results)


class MUX8To1(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = MuxBuilder(3)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        results = [and_gate.get_output([data_bit] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data)]
        return or_gate.get_output(results)


class MUX16To1(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = MuxBuilder(4)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        results = [and_gate.get_output([data_bit] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data)]
        return or_gate.get_output(results)


class MUX32To1(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = MuxBuilder(5)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        results = [and_gate.get_output([data_bit] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data)]
        return or_gate.get_output(results)


class MUX64To1(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = MuxBuilder(6)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        results = [and_gate.get_output([data_bit] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data)]
        return or_gate.get_output(results)


class MUX128To1(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = MuxBuilder(7)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        results = [and_gate.get_output([data_bit] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data)]
        return or_gate.get_output(results)