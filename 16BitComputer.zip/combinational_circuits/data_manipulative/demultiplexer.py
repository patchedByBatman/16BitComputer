from imports.gates.allGates import *
from imports.circuit import Circuit
from imports.general_imports import *

class DeMuxBuilder(Circuit):
    def __init__(self, num_address_pins):
        super().__init__()
        self.num_address_pins = num_address_pins
        self.num_data_in = 2**self.num_address_pins
        self.selection_logic_data = [[int(j) for j in format(i, "0{}b".format(self.num_address_pins))] for i in range(self.num_data_in)]


class DMUX1ToN(Circuit):
    def __init__(self, num_data_lines):
        super().__init__()
        self.num_data_lines = num_data_lines
        self.__mux_builder = DeMuxBuilder(num_data_lines)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        return [and_gate.get_output([data] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for logic in self.__mux_builder.selection_logic_data]


class DMUX1To2(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = DeMuxBuilder(1)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        return [and_gate.get_output([data] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for logic in self.__mux_builder.selection_logic_data]


class DMUX1To4(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = DeMuxBuilder(2)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        return [and_gate.get_output([data] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for logic in self.__mux_builder.selection_logic_data]


class DMUX1To8(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = DeMuxBuilder(3)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        return [and_gate.get_output([data] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for logic in self.__mux_builder.selection_logic_data]


class DMUX1To16(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = DeMuxBuilder(4)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        return [and_gate.get_output([data] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for logic in self.__mux_builder.selection_logic_data]


class DMUX1To32(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = DeMuxBuilder(5)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        return [and_gate.get_output([data] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for logic in self.__mux_builder.selection_logic_data]


class DMUX1To64(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = DeMuxBuilder(6)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        return [and_gate.get_output([data] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for logic in self.__mux_builder.selection_logic_data]


class DMUX1To128(Circuit):
    def __init__(self):
        super().__init__()
        self.__mux_builder = DeMuxBuilder(7)

    def get_output(self, data, address):
        """
        results = []
        for data_bit, logic in zip(data, self.__mux_builder.selection_logic_data):
            logic_sequence = []
            for i, address_bit in enumerate(address):
                print(logic, i)
                logic_sequence.append(not_gate.get_output(address_bit) if logic[i] == 0 else address_bit)
            results.append(and_gate.get_output([data_bit] + logic_sequence))
        """
        return [and_gate.get_output([data] + [not_gate.get_output(address_bit) if logic[i] == 0 else address_bit for i, address_bit in enumerate(address)]) for logic in self.__mux_builder.selection_logic_data]
