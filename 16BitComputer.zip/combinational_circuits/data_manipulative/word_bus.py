from imports.general_imports import *
from imports.gates.allGates import *
from imports.combinational_logic.data_manipulative import *
from imports.circuit import *


class BUS(Circuit):
    def __init__(self, bus_label):
        super().__init__()
        self.bus_label = bus_label
        self.bus_data = [None]*16

    def get_bus_current_data(self):
        return self.bus_data

    def float_bus_data(self):
        self.bus_data = [None]*16

    def get_output(self, word_array):
        self.bus_data = word_array[:]
        return self.bus_data

    def get_outputs(self, word_array):
        bit_sequence = []
        temp = []
        for i in range(len(word_array[0])):
            for j in range(len(word_array)):
                temp.append(word_array[j][i])
            bit_sequence.append(set(temp))
            temp = []
        bit_sequence = [seq - {None} for seq in bit_sequence]
        for seq in bit_sequence:
            if len(seq) > 1:
                raise Exceptions.BusDataCorrupt(bit_sequence, word_array)
        bit_sequence = [int(bit.pop()) if len(bit) else None for bit in bit_sequence]
        self.bus_data = bit_sequence[:]
        return self.bus_data
