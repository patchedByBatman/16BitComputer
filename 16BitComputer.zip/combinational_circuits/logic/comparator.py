from imports.combinational_logic.arithmetic import *
from imports.circuit import Circuit


class WordComparator(Circuit):
    def __init__(self, device_id):
        super().__init__()
        self.device_id = device_id

    def get_outputs(self, word_a, word_b):
        result = word_subtractor_ckt.get_outputs(word_a, word_b)
        sign_bit = result[1]
        __or = or_gate.get_output(result[0])
        __greater = and_gate.get_output([__or, not_gate.get_output(sign_bit)])
        __equal = and_gate.get_output([not_gate.get_output(__or)])
        __less = and_gate.get_output([__or, sign_bit])
        current_data_in_flag_reg = cpu_flag_register.get_outputs(zeros, byte_generator(0x1A))

        return [
            current_data_in_flag_reg[0],
            __less,
            __equal,
            __greater,
            or_gate.get_output([__greater, __equal]),
            __less,
            or_gate.get_output([__less, __equal]),
            __equal,
            not_gate.get_output(__equal),
            current_data_in_flag_reg[9],
            current_data_in_flag_reg[10],
            current_data_in_flag_reg[11],
            current_data_in_flag_reg[12],
            current_data_in_flag_reg[13],
            current_data_in_flag_reg[14],
            current_data_in_flag_reg[15]
        ]
