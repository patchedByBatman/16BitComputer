from combinational_circuits.arithmetic.adder import *
from combinational_circuits.arithmetic.subtractor import *
from binary_data.binary import DATA
from imports.combinational_logic.logic import *
import numpy as np

ip = np.array([1,0], dtype=np.int8)
ip2 = np.array([1,1,1], dtype=np.int8)
ipa = np.array([np.int16(i) for i in format(25, "016b")])
ipb = np.array([np.int16(i) for i in format(2, "016b")])
ha = HalfAdder()
fa = FullAdder()
wa = WordAdder()
ws = WordSubtractor()
print(ha.get_outputs(ip))
print(fa.get_outputs(ip2))
op = wa.get_outputs(ipa, ipb, 0)
op2 = ws.get_outputs(ipa, ipb)
print(op2)
print(int('0b' + ''.join([str(i) for i in op[0]]), 2))
op3 = int('0b' + ''.join([str(i) for i in op2[0]]), 2)
print(op3 if op2[1] == 0 else -op3)

print(word_comparator_ckt.get_outputs(ipa, ipb))

