from imports.general_imports import *
from imports.gates.allGates import *
from imports.combinational_logic.logic import *
from imports.combinational_logic.data_manipulative import *
from imports.combinational_logic.arithmetic import *
from imports.circuit import *
from CPU.cpu_regs import *
from CPU.ALU import *

"""
main_loop actions:
1) counter starts
2) counter increments
3) loads cpu_program_counter_register with current counter value
4) fetches instructions @cpu_program_counter_register in programme memory
    and loads it into cpu_instruction_register via <<<instruction_bus>>>
5) CU reads cpu_instruction_register
6) CU generates <<<device_selection_bus>>>, 
"""

"""
____________________________________________________________
sel_l | read_write_bar |        state
------------------------------------------------------------
    0 |             0  | op = hi_z : ip = d_in (store data)
    0 |             1  | op = data : ip = none (retrieve)
    1 |             0  | op = hi_z : ip = none (none)
    1 |             1  | op = hi_z : ip = none (none)
------------------------------------------------------------
"""
"""
device_selection_bus data pattern:
    BITS :  15<------------>8 7<------------->0             
            [ o/p device ID ] [ i/p device ID ]
            to simplify selection circuit design,
            the LSBs {8, 0} indicate o/p, i/p
            the rest of the 7 bits 15->9 and 7->1 are same and
            are the device_id bits that indicate device ID 
            for example:
            [0b0000010]{0}(04H) indicate cpu_C_register in i/p mode
            [0b0000010]{1}(05H) indicate cpu_C_register in o/p mode
            here the bits in square_braces indicate device ID
            the bit in flower_braces indicate o/p or i/p mode
    _____________________________________________________________
    byte_code |                   device                   | mode
    -------------------------------------------------------------
        00H   |               cpu_A_register               | o/p
        01H   |               cpu_A_register               | i/p
        02H   |               cpu_B_register               | o/p
        03H   |               cpu_B_register               | i/p
        04H   |               cpu_C_register               | o/p
        05H   |               cpu_C_register               | i/p
        06H   |               cpu_D_register               | o/p
        07H   |               cpu_D_register               | i/p
        08H   |       cpu_memory_address_register_1_H      | o/p
        09H   |       cpu_memory_address_register_1_H      | i/p
        F8H   |       cpu_memory_address_register_1_L      | o/p
        F9H   |       cpu_memory_address_register_1_L      | i/p
        0AH   |       cpu_memory_address_register_2_H      | o/p
        0BH   |       cpu_memory_address_register_2_H      | i/p
        FAH   |       cpu_memory_address_register_2_L      | o/p
        FBH   |       cpu_memory_address_register_2_L      | i/p
        0CH   |         cpu_memory_data_register_1         | o/p
        0DH   |         cpu_memory_data_register_1         | i/p
        0EH   |         cpu_memory_data_register_2         | o/p
        0FH   |         cpu_memory_data_register_2         | i/p
        10H   |cpu_general_purpose_register_grid16x16[0-15]| o/p
        11H   |cpu_general_purpose_register_grid16x16[0-15]| i/p
        12H   |        cpu_program_counter_register        | o/p
        13H   |        cpu_program_counter_register        | i/p
        14H   |          cpu_instruction_register          | o/p
        15H   |          cpu_instruction_register          | i/p
        16H   |         cpu_stack_pointer_register         | o/p
        17H   |         cpu_stack_pointer_register         | i/p
        18H   |           cpu_stack_data_register          | o/p
        19H   |           cpu_stack_data_register          | i/p
        1AH   |              cpu_flag_register             | o/p
        1BH   |              cpu_flag_register             | i/p
        1CH   |                system_memory               | o/p
        1DH   |                system_memory               | i/p
        1EH   |                  ALU_ADDER                 | o/p
        1FH   |                  ALU_ADDER                 | i/p
        20H   |               ALU_SUBTRACTOR               | o/p
        21H   |               ALU_SUBTRACTOR               | i/p
        22H   |               ALU_MULTIPLIER               | o/p
        23H   |               ALU_MULTIPLIER               | i/p
        24H   |                 ALU_DIVIDER                | o/p
        25H   |                 ALU_DIVIDER                | i/p
        26H   |               ALU_COMPARATOR               | o/p
        27H   |               ALU_COMPARATOR               | i/p
        28H   |             ALU_BIT_COMPARATOR             | o/p
        29H   |             ALU_BIT_COMPARATOR             | i/p
    cpu_regs and MEMORY: for each [sel_l, read_write_bar]               
        0) cpu_A_register
        1) cpu_A_register_type_indicators
        2) cpu_B_register
        3) cpu_B_register_type_indicators
        4) cpu_C_register
        5) cpu_C_register_type_indicators
        6) cpu_D_register
        7) cpu_D_register_type_indicators
        
        8) cpu_memory_address_register_1
        9) cpu_memory_address_register_2
       10) cpu_memory_data_register_1
       11) cpu_memory_data_register_2
       12) cpu_general_purpose_register_grid16x16
       13) cpu_general_purpose_register_grid16x16_type_indicators
       14) cpu_program_counter_register
       15) cpu_instruction_register
       16) cpu_stack_pointer_register
       17) cpu_stack_data_register
       18) cpu_stack_data_register_type_indicator
       19) cpu_flag_register
       
       20) system_memory
       21) system_memory_type_indicator
       
    ALU: for each [read_to_bus, dont_care]
       22) ADD word_adder_ckt
       23) INC word_adder_ckt
       24) DINC word_adder_ckt
       25) SUB word_subtractor_ckt
       26) DEC word_subtractor_ckt
       27) DDEC word_subtractor_ckt
       28) MUL word_multiplier_ckt
       29) DBL word_multiplier_ckt
       30) DIV word_divider_ckt
       31) HALF word_divider_ckt
"""


class ControlUnit(Circuit):
    def __init__(self):
        super().__init__()
        self.alu = ALU()
        self.change_bus_data = 0

    def __gen_op_device_byte_code(self, op_code):
        B15 = and_gate.get_output(not_gate.get_outputs(op_code))  # a'b'c'd'e'f'g'h'
        B14 = and_gate.get_output(not_gate.get_outputs(op_code))  # a'b'c'd'e'f'g'h'
        B13 = or_gate.get_output(
            [
                and_gate.get_output(not_gate.get_outputs(op_code)),
                and_gate.get_output(
                    [
                        not_gate.get_output(op_code[0]),
                        not_gate.get_output(op_code[1]),
                        op_code[2],
                        op_code[3],
                        not_gate.get_output(op_code[5]),
                        op_code[6],
                        not_gate.get_output(op_code[7])
                    ]
                ),
                and_gate.get_output(
                    [
                        not_gate.get_output(op_code[0]),
                        not_gate.get_output(op_code[1]),
                        op_code[2],
                        op_code[3],
                        op_code[4],
                        op_code[7]
                    ]
                ),
                and_gate.get_output(
                    [
                        not_gate.get_output(op_code[0]),
                        not_gate.get_output(op_code[1]),
                        op_code[2],
                        op_code[3],
                        op_code[4],
                        op_code[5]
                    ]
                )
            ]
        )  # a'b'c'd'e'f'g'h' + a'b'cdf'gh' + a'b'cdeh + a'b'cdef
        B12 = or_gate.get_output(
            [
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            op_code[5],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            op_code[5],
                            op_code[6]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            op_code[4],
                            not_gate.get_output(op_code[5]),
                            op_code[6],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            op_code[4],
                            op_code[5],
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            op_code[6],
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            op_code[4],
                            op_code[5],
                            op_code[6],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            op_code[5],
                            not_gate.get_output(op_code[6]),
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            op_code[4],
                            op_code[5],
                            op_code[6]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                )
            ]
        )  # a'b'c'd'f'g'h' + a'b'c'd'e'fh + a'b'c'd'e'fg + a'b'c'def'gh + a'b'c'defg'h' + a'b'cd'e'f'g'h
        # + a'b'cd'e'f'gh' + a'b'cd'efgh + a'bc'dfg'h + a'bc'defg + a'bcd'e'f'g'h'
        B11 = or_gate.get_output(
            [
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[4])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[5])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[3]),
                            op_code[4],
                            op_code[5],
                            op_code[6],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[5]),
                            op_code[6]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            op_code[4],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            op_code[4],
                            op_code[5]
                        ]
                )
            ]
        )  # a'b'c'de' + a'b'c'df' + a'b'd'e'f'g'h + a'b'd'efgh
        # + a'b'c'e'g'h' + a'b'c'f'g + a'b'c'd'eh + a'b'c'd'ef
        B10 = or_gate.get_output(
            [
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[4])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            op_code[3],
                            op_code[4],
                            op_code[5]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            op_code[6],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            op_code[5],
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[3],
                            op_code[4],
                            not_gate.get_output(op_code[5]),
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[4],
                            op_code[5],
                            op_code[6],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            op_code[5],
                            op_code[6]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[3],
                            op_code[4],
                            not_gate.get_output(op_code[5]),
                            op_code[6]
                        ]
                )
            ]
        ) # a'b'c'd' + a'b'c'e' + a'b'd'f'g'h' + a'b'cdef + a'c'de'f' + a'c'df'h' + a'bc'dg'h' + a'bcd'e'f'gh
        # + a'bcd'e'fg'h' + a'b'def'h + a'b'efgh + a'b'd'e'f'h' + a'b'd'e'fg + a'b'def'g
        B9 = or_gate.get_output(
            [
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[3],
                            op_code[4],
                            op_code[5],
                            op_code[6],
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            op_code[4],
                            op_code[5],
                            op_code[6],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            op_code[3],
                            op_code[4],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            op_code[3],
                            op_code[4],
                            op_code[6]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            op_code[3],
                            op_code[4],
                            op_code[5]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[6])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[5]),
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            op_code[6],
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            op_code[5],
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                )
            ]
        )  # a'b'd'e'f'g'h' + a'b'defgh' + a'b'cd'e'f'g' + a'b'cd'f'g'h' + a'b'cefgh + a'b'cdeh + a'b'cdeg + a'b'cdef + a'bc'de'f'
        # + a'bc'de'g' + a'bc'df'h + a'bc'dg'h' + a'cd'e'f'gh' + a'cd'e'fg'h'
        B8 = and_gate.get_output(not_gate.get_outputs(op_code))  # a'b'c'd'e'f'g'h'
        B7 = or_gate.get_output(
            [
                and_gate.get_output(
                    [
                        not_gate.get_output(op_code[0]),
                        not_gate.get_output(op_code[1]),
                        not_gate.get_output(op_code[2]),
                        not_gate.get_output(op_code[3]),
                        not_gate.get_output(op_code[5]),
                        not_gate.get_output(op_code[6]),
                        not_gate.get_output(op_code[7])
                    ]
                ),
                and_gate.get_output(
                    [
                        not_gate.get_output(op_code[0]),
                        not_gate.get_output(op_code[1]),
                        not_gate.get_output(op_code[2]),
                        not_gate.get_output(op_code[3]),
                        not_gate.get_output(op_code[4]),
                        op_code[5],
                        op_code[6],
                        not_gate.get_output(op_code[7])
                    ]
                )
            ]
        )  # a'b'c'd'f'g'h' + a'b'c'd'e'fgh'
        B6 = or_gate.get_output(
            [
                and_gate.get_output(
                    [
                        not_gate.get_output(op_code[0]),
                        not_gate.get_output(op_code[1]),
                        not_gate.get_output(op_code[2]),
                        not_gate.get_output(op_code[3]),
                        not_gate.get_output(op_code[5]),
                        not_gate.get_output(op_code[6]),
                        not_gate.get_output(op_code[7])
                    ]
                ),
                and_gate.get_output(
                    [
                        not_gate.get_output(op_code[0]),
                        not_gate.get_output(op_code[1]),
                        not_gate.get_output(op_code[2]),
                        not_gate.get_output(op_code[3]),
                        not_gate.get_output(op_code[4]),
                        op_code[5],
                        op_code[6],
                        not_gate.get_output(op_code[7])
                    ]
                )
            ]
        )  # a'b'c'd'f'g'h' + a'b'c'd'e'fgh'
        B5 = or_gate.get_output(
            [
                and_gate.get_output(
                    [
                        not_gate.get_output(op_code[0]),
                        not_gate.get_output(op_code[1]),
                        not_gate.get_output(op_code[2]),
                        not_gate.get_output(op_code[3]),
                        not_gate.get_output(op_code[5]),
                        not_gate.get_output(op_code[6]),
                        not_gate.get_output(op_code[7])
                    ]
                ),
                and_gate.get_output(
                    [
                        not_gate.get_output(op_code[0]),
                        not_gate.get_output(op_code[1]),
                        not_gate.get_output(op_code[2]),
                        not_gate.get_output(op_code[3]),
                        not_gate.get_output(op_code[4]),
                        op_code[5],
                        op_code[6],
                        not_gate.get_output(op_code[7])
                    ]
                )
            ]
        )  # a'b'c'd'f'g'h' + a'b'c'd'e'fgh'
        B4 = or_gate.get_output(
            [
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            op_code[5],
                            op_code[6],
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            op_code[4]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            op_code[3]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[3],
                            op_code[4],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[3],
                            op_code[4],
                            op_code[6]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[3],
                            op_code[4],
                            op_code[5]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[6])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            op_code[5],
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            op_code[6],
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            op_code[7]
                        ]
                )
            ]
        ) # a'b'c'fgh' + a'b'c'e + a'b'c'd + a'b'deh + a'b'deg + a'b'def + a'c'de'f' + a'c'de'g'
        # + a'bcd'e'fg'h' + a'b'd'e'f'g'h' + a'b'cd'e'f'g' + a'cd'e'f'gh' + a'bcd'e'f'h
        B3 = or_gate.get_output(
            [
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            op_code[5],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            op_code[5],
                            op_code[6]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[3],
                            op_code[4],
                            op_code[6],
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[3],
                            op_code[4],
                            op_code[5]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            op_code[3],
                            op_code[4],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[4]),
                            op_code[5],
                            not_gate.get_output(op_code[6]),
                            op_code[7]
                        ]
                )
            ]
        ) # a'b'c'd'e'fh + a'b'c'd'e'fg + a'b'c'd'f'g'h' + a'b'degh'
        # + a'b'def + a'b'cd'e'f'g' + a'b'cd'e'f'h' + a'b'cdeh + a'bc'de'fg'h

        B2 = or_gate.get_output(
            [
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            op_code[6],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            op_code[4],
                            op_code[5]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            op_code[5],
                            op_code[6],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            op_code[6],
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[4]),
                            op_code[5],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            op_code[4],
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[6]),
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            op_code[4],
                            op_code[6],
                            op_code[7]
                        ]
                )
            ]
        )  # a'b'c'd'e'f'gh + a'b'c'd'e'g'h' + a'b'c'def + a'b'cd'f'g'h' + a'b'cd'fgh + a'b'ce'f'gh'
        # + a'bc'de'fh + a'cd'e'f'g'h' + a'c'def'g'h + a'b'cd'e'g'h + a'bc'degh
        B1 = or_gate.get_output(
            [
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            op_code[5],
                            op_code[6],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            not_gate.get_output(op_code[2]),
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[3],
                            op_code[4],
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            op_code[6],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            op_code[3],
                            op_code[4],
                            op_code[5]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[4]),
                            op_code[6],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[5]),
                            op_code[6]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            op_code[2],
                            not_gate.get_output(op_code[3]),
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[5]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[3],
                            op_code[4],
                            not_gate.get_output(op_code[5]),
                            op_code[6],
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            not_gate.get_output(op_code[1]),
                            op_code[2],
                            op_code[3],
                            op_code[4],
                            op_code[7]
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            not_gate.get_output(op_code[4]),
                            not_gate.get_output(op_code[6]),
                            not_gate.get_output(op_code[7])
                        ]
                ),
                and_gate.get_output(
                        [
                            not_gate.get_output(op_code[0]),
                            op_code[1],
                            not_gate.get_output(op_code[2]),
                            op_code[3],
                            op_code[4],
                            op_code[5],
                            not_gate.get_output(op_code[7])
                        ]
                )
            ]
        )  # a'b'c'd'e'f'h' + a'b'c'd'e'g'h' + a'b'd'e'fgh + a'b'c'd'f'g'h' + a'b'def'g'h + a'b'cd'e'gh + a'b'cdef + a'bc'de'f' + a'bc'de'gh
        # + a'bc'df'g + a'bcd'e'f'g'h' + a'b'def'gh' + a'b'cdeh + a'bc'de'g'h' + a'bc'defh'
        B0 = 1  # from device_selection_bus data table for i/p B0 is always 1, so no SOP equation is needed

        """
        B0 : 0,1,2,3,4,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,29,30,31,32,33,34,35,36,37,38,39,40,47,50,57,58,59,60,61,62,63,80,81,82,83,84,85
        a'b'c'df'g'h' + a'b'cd'e' + a'b'cd'f'g'h' + a'b'cdeh + a'b'cdef + a'c'de'f' + a'c'de'g' + a'b'c'e'g'h' + a'b'c'd'f'h + a'b'c'd'f'g + a'b'c'd'ef + a'b'c'dfg + a'b'c'dfh + a'b'cd'fgh + a'b'cdf'gh'
        """
        return [B15, B14, B13, B12, B11, B10, B9, B8], \
               [B7, B6, B5, B4, B3, B2, B1, B0]

    def __fetch_clock_based_code(self, byte_or_word_code, clock_state):
        return [and_gate.get_output([clock_state, bit]) for bit in byte_or_word_code]

    def main_loop(self, op_code):
        # generating device_selection byte codes
        op_dev, ip_dev = self.__gen_op_device_byte_code(op_code[:8])
        # print("in cu : ", op_dev, ip_dev)
        # print("in cu : ", op_code, op_dev, ip_dev)

        # immediate load addresses
        address_bus.get_output(
            cpu_memory_address_register_1[0].get_outputs(zeros, byte_generator(0x08)) +
            cpu_memory_address_register_1[1].get_outputs(zeros, byte_generator(0xF8))
        )
        gp_address_bus.get_output(
            cpu_memory_address_register_2[0].get_outputs(zeros, byte_generator(0x0A)) +
            cpu_memory_address_register_2[1].get_outputs(zeros, byte_generator(0xFA))
        )

        # immediate load data to mem_regs
        cpu_memory_data_register_1.get_outputs(
            system_memory.get_outputs(zeros, address_bus.get_bus_current_data(), byte_generator(0x1C)),
            byte_generator(0x0D)
        )
        cpu_memory_data_register_1_type_indicators.get_outputs(
            system_memory_type_indicator.get_outputs(zeros, address_bus.get_bus_current_data(), byte_generator(0x1C)),
            byte_generator(0x0D)
        )
        cpu_memory_data_register_2.get_outputs(
            cpu_general_purpose_register_grid16x16.get_outputs(
                zeros, gp_address_bus.get_bus_current_data()[-4:], byte_generator(0x10)
            ),
            byte_generator(0x0F)
        )
        cpu_memory_data_register_2_type_indicators.get_outputs(
            cpu_general_purpose_register_grid16x16_type_indicators.get_outputs(
                zeros, gp_address_bus.get_bus_current_data()[-4:], byte_generator(0x10)
            ),
            byte_generator(0x0F)
        )

        # place output device data on data_bus
        adder_result = self.alu.add(op_dev)
        subtrator_result = self.alu.sub(op_dev)
        data_bus.get_outputs(
            [
                # todo add and sub return tuples fix this so that you need no indexing
                cpu_A_register.get_outputs(zeros, op_dev),
                cpu_B_register.get_outputs(zeros, op_dev),
                cpu_C_register.get_outputs(zeros, op_dev),
                cpu_D_register.get_outputs(zeros, op_dev),
                cpu_memory_address_register_1[0].get_outputs(zeros, op_dev) +
                cpu_memory_address_register_1[1].get_outputs(zeros, byte_generator(0xF0)[:4] + op_dev[4:]),
                cpu_memory_address_register_2[0].get_outputs(zeros, op_dev) +
                cpu_memory_address_register_2[1].get_outputs(zeros, byte_generator(0xF0)[:4] + op_dev[4:]),
                cpu_memory_data_register_1.get_outputs(zeros, op_dev),
                cpu_memory_data_register_2.get_outputs(zeros, op_dev),
                cpu_general_purpose_register_grid16x16.get_outputs(zeros, gp_address_bus.get_bus_current_data()[-4:],
                                                                   op_dev),
                # cpu_general_purpose_register_grid16x16_type_indicators.get_outputs(zeros, op_dev),
                cpu_program_counter_register.get_outputs(zeros, op_dev),
                cpu_instruction_register.get_outputs(zeros, op_dev),
                cpu_stack_pointer_register.get_outputs(zeros, op_dev),
                cpu_stack_data_register.get_outputs(zeros, op_dev),
                # cpu_stack_data_register_type_indicator.get_outputs(zeros, op_dev),
                cpu_flag_register.get_outputs(zeros, op_dev),
                system_memory.get_outputs(zeros, address_bus.get_bus_current_data(), op_dev),
                # system_memory_type_indicator.get_outputs(zeros, op_dev),
                adder_result[0],
                subtrator_result[0],
                self.alu.cmp(op_dev)
            ]
        )
        type_indicator_bus.get_outputs(
            [
                cpu_A_register_type_indicators.get_outputs(zeros, op_dev),
                cpu_B_register_type_indicators.get_outputs(zeros, op_dev),
                cpu_C_register_type_indicators.get_outputs(zeros, op_dev),
                cpu_D_register_type_indicators.get_outputs(zeros, op_dev),
                cpu_memory_data_register_1_type_indicators.get_outputs(zeros, op_dev),
                cpu_memory_data_register_2_type_indicators.get_outputs(zeros, op_dev),
                cpu_general_purpose_register_grid16x16_type_indicators.get_outputs(
                    zeros, gp_address_bus.get_bus_current_data()[-4:], op_dev
                ),
                cpu_stack_data_register_type_indicator.get_outputs(zeros, op_dev),
                system_memory_type_indicator.get_outputs(zeros, address_bus.get_bus_current_data(), op_dev),
                [subtrator_result[1], None, None]
            ]
        )
        # first update flag_register because it contains crucial flags
        current_data_in_flag_reg = cpu_flag_register.get_outputs(zeros, byte_generator(0x1A))
        flags = [
            over_flow_flag := adder_result[1] if adder_result[1] is not None else 0,
            barrow_flag := subtrator_result[1] if subtrator_result[1] is not None else 0,
            zero_flag := and_gate.get_output(
                not_gate.get_outputs(
                    cpu_C_register.get_outputs(zeros, byte_generator(0x04))
                )
            ),
            greater_flag := current_data_in_flag_reg[3],  # will be changed by Comparator
            greater_or_equal_flag := current_data_in_flag_reg[4],  # will be changed by Comparator
            less_flag := current_data_in_flag_reg[5],  # will be changed by Comparator
            less_or_equal_flag := current_data_in_flag_reg[6],  # will be changed by Comparator
            equal_flag := current_data_in_flag_reg[7],  # will be changed by Comparator
            not_equal_flag := current_data_in_flag_reg[8],  # will be changed by Comparator
            op_code_err_flag := current_data_in_flag_reg[9],
            data_corrupt_flag := current_data_in_flag_reg[10],
            sleep_flag := current_data_in_flag_reg[11],
            halt_flag := and_gate.get_output(op_dev + ip_dev),
            eve_parrity_A_flag := xor_gate.get_output(
                cpu_A_register.get_outputs(zeros, byte_generator(0x00))
            ),
            eve_parrity_B_flag := xor_gate.get_output(
                cpu_B_register.get_outputs(zeros, byte_generator(0x02))
            ),
            eve_parrity_C_flag := xor_gate.get_output(
                cpu_C_register.get_outputs(zeros, byte_generator(0x04))
            )
        ]
        cpu_flag_register.get_outputs(flags, byte_generator(0x1B))

        # forwarding output on data_bus to input device
        cpu_A_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_B_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_C_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_D_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_memory_address_register_1[0].get_outputs(data_bus.get_bus_current_data()[8:], ip_dev)
        cpu_memory_address_register_1[1].get_outputs(
            data_bus.get_bus_current_data()[8:],
            ip_dev
        )
        cpu_memory_address_register_2[0].get_outputs(data_bus.get_bus_current_data()[8:], ip_dev)
        cpu_memory_address_register_2[1].get_outputs(
            data_bus.get_bus_current_data()[8:],
            ip_dev
        )
        cpu_memory_data_register_1.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_memory_data_register_2.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_general_purpose_register_grid16x16.get_outputs(
            data_bus.get_bus_current_data(), gp_address_bus.get_bus_current_data()[-4:], ip_dev
        )

        cpu_flag_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        flag_bits = cpu_flag_register.get_outputs(zeros, byte_generator(0x1A))
        __ze = flag_bits[15 - 13]  # bit number to index conversion
        __g = flag_bits[15 - 12]  # bit number to index conversion
        __l = flag_bits[15 - 10]  # bit number to index conversion
        jump_flag = or_gate.get_output(
                [
                    and_gate.get_output(
                            [
                                not_gate.get_output(op_code[0]),
                                op_code[1],
                                not_gate.get_output(op_code[2]),
                                op_code[3],
                                not_gate.get_output(op_code[4]),
                                not_gate.get_output(op_code[5]),
                                not_gate.get_output(op_code[6]),
                                not_gate.get_output(op_code[7])
                            ]
                    ),
                    and_gate.get_output(
                            [
                                not_gate.get_output(op_code[0]),
                                op_code[1],
                                not_gate.get_output(op_code[2]),
                                op_code[3],
                                not_gate.get_output(op_code[4]),
                                not_gate.get_output(op_code[5]),
                                not_gate.get_output(op_code[6]),
                                __ze,
                                not_gate.get_output(__g),
                                not_gate.get_output(__l)
                            ]
                    ),
                    and_gate.get_output(
                            [
                                not_gate.get_output(op_code[0]),
                                op_code[1],
                                not_gate.get_output(op_code[2]),
                                op_code[3],
                                not_gate.get_output(op_code[4]),
                                not_gate.get_output(op_code[5]),
                                not_gate.get_output(op_code[7]),
                                not_gate.get_output(__ze)
                            ]
                    ),
                    and_gate.get_output(
                            [
                                not_gate.get_output(op_code[0]),
                                op_code[1],
                                not_gate.get_output(op_code[2]),
                                op_code[3],
                                not_gate.get_output(op_code[4]),
                                not_gate.get_output(op_code[5]),
                                op_code[6],
                                not_gate.get_output(__ze),
                                __g,
                                not_gate.get_output(__l)
                            ]
                    ),
                    and_gate.get_output(
                            [
                                not_gate.get_output(op_code[0]),
                                op_code[1],
                                not_gate.get_output(op_code[2]),
                                op_code[3],
                                not_gate.get_output(op_code[4]),
                                not_gate.get_output(op_code[6]),
                                not_gate.get_output(op_code[7]),
                                not_gate.get_output(__ze),
                                not_gate.get_output(__g),
                                __l
                            ]
                    )
                ]
            )
        cpu_program_counter_register.get_outputs(
            data_bus.get_bus_current_data(),
            [
                and_gate.get_output(
                    [
                        jump_flag,
                        ip_dev_bit,
                        not_gate.get_output(halt_flag)
                    ]
                ) for ip_dev_bit in ip_dev]
        )
        cpu_instruction_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_stack_pointer_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_stack_data_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        system_memory.get_outputs(data_bus.get_bus_current_data(), address_bus.get_bus_current_data(), ip_dev)

        cpu_A_register_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_B_register_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_C_register_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_D_register_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_memory_data_register_1_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_memory_data_register_2_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_general_purpose_register_grid16x16_type_indicators.get_outputs(
            type_indicator_bus.get_bus_current_data(), gp_address_bus.get_bus_current_data()[-4:], ip_dev
        )
        cpu_stack_data_register_type_indicator.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        system_memory_type_indicator.get_outputs(
            type_indicator_bus.get_bus_current_data(), address_bus.get_bus_current_data(), ip_dev
        )
        """print(
            "in cu 3 : ",
            cpu_memory_address_register_1[0].get_outputs(zeros, byte_generator(0x08)),
            cpu_memory_address_register_1[1].get_outputs(zeros, byte_generator(0xF8))
        )"""

    def simulation_optimized_main_loop(self, op_code, current_clock_state):
        # generating device_selection byte codes
        op_dev, ip_dev = self.__gen_op_device_byte_code(op_code[:8])
        op_dev = self.__fetch_clock_based_code(op_dev, current_clock_state)
        ip_dev = self.__fetch_clock_based_code(ip_dev, current_clock_state)

        # immediate load addresses
        address_bus.get_output(
            cpu_memory_address_register_1[0].get_outputs(zeros, byte_generator(0x08)) +
            cpu_memory_address_register_1[1].get_outputs(zeros, byte_generator(0x09))
        )
        gp_address_bus.get_output(
            cpu_memory_address_register_2[0].get_outputs(zeros, byte_generator(0x0A)) +
            cpu_memory_address_register_2[1].get_outputs(zeros, byte_generator(0x0B))
        )

        # immediate load data to mem_regs
        cpu_memory_data_register_1.get_outputs(
            system_memory.get_outputs(zeros, address_bus.get_bus_current_data(), byte_generator(0x1C)),
            byte_generator(0x0D)
        )
        cpu_memory_data_register_1_type_indicators.get_outputs(
            system_memory_type_indicator.get_outputs(zeros, address_bus.get_bus_current_data(), byte_generator(0x1C)),
            byte_generator(0x0D)
        )
        cpu_memory_data_register_2.get_outputs(
            cpu_general_purpose_register_grid16x16.get_outputs(
                zeros, gp_address_bus.get_bus_current_data()[-4:], byte_generator(0x10)
            ),
            byte_generator(0x0F)
        )
        cpu_memory_data_register_2_type_indicators.get_outputs(
            cpu_general_purpose_register_grid16x16_type_indicators.get_outputs(
                zeros, gp_address_bus.get_bus_current_data()[-4:], byte_generator(0x10)
            ),
            byte_generator(0x0F)
        )

        # place output device data on data_bus
        data_bus.get_outputs(
            [
                # todo add and sub return tuples fix this so that you need no indexing
                cpu_A_register.get_outputs(zeros, op_dev),
                cpu_B_register.get_outputs(zeros, op_dev),
                cpu_C_register.get_outputs(zeros, op_dev),
                cpu_D_register.get_outputs(zeros, op_dev),
                cpu_memory_address_register_1.get_outputs(zeros, op_dev),
                cpu_memory_address_register_2.get_outputs(zeros, op_dev),
                cpu_memory_data_register_1.get_outputs(zeros, op_dev),
                cpu_memory_data_register_2.get_outputs(zeros, op_dev),
                cpu_general_purpose_register_grid16x16.get_outputs(zeros, gp_address_bus.get_bus_current_data()[-4:],
                                                                   op_dev),
                # cpu_general_purpose_register_grid16x16_type_indicators.get_outputs(zeros, op_dev),
                cpu_program_counter_register.get_outputs(zeros, op_dev),
                cpu_instruction_register.get_outputs(zeros, op_dev),
                cpu_stack_pointer_register.get_outputs(zeros, op_dev),
                cpu_stack_data_register.get_outputs(zeros, op_dev),
                # cpu_stack_data_register_type_indicator.get_outputs(zeros, op_dev),
                cpu_flag_register.get_outputs(zeros, op_dev),
                system_memory.get_outputs(zeros, address_bus.get_bus_current_data(), op_dev),
                # system_memory_type_indicator.get_outputs(zeros, op_dev),
                self.alu.add(op_dev)[0],
                self.alu.sub(op_dev)[0]
            ]
        )
        type_indicator_bus.get_outputs(
            [
                cpu_A_register_type_indicators.get_outputs(zeros, op_dev),
                cpu_B_register_type_indicators.get_outputs(zeros, op_dev),
                cpu_C_register_type_indicators.get_outputs(zeros, op_dev),
                cpu_D_register_type_indicators.get_outputs(zeros, op_dev),
                cpu_memory_data_register_1_type_indicators.get_outputs(zeros, op_dev),
                cpu_memory_data_register_2_type_indicators.get_outputs(zeros, op_dev),
                cpu_general_purpose_register_grid16x16_type_indicators.get_outputs(
                    zeros, gp_address_bus.get_bus_current_data()[-4:], op_dev
                ),
                cpu_stack_data_register_type_indicator.get_outputs(zeros, op_dev),
                system_memory_type_indicator.get_outputs(zeros, address_bus.get_bus_current_data(), op_dev),
                # self.alu.add(op_dev)[1],
                # self.alu.sub(op_dev)[1]
            ]
        )

        # forwarding output on data_bus to input device
        cpu_A_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_B_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_C_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_D_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        # todo implement LDAMA[1/2][H/L] logic
        cpu_memory_address_register_1.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_memory_address_register_2.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_memory_data_register_1.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_memory_data_register_2.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_general_purpose_register_grid16x16.get_outputs(
            data_bus.get_bus_current_data(), gp_address_bus.get_bus_current_data()[-4:], ip_dev
        )
        cpu_program_counter_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_instruction_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_stack_pointer_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_stack_data_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        cpu_flag_register.get_outputs(data_bus.get_bus_current_data(), ip_dev)
        system_memory.get_outputs(data_bus.get_bus_current_data(), address_bus.get_bus_current_data(), ip_dev)

        cpu_A_register_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_B_register_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_C_register_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_D_register_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_memory_data_register_1_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_memory_data_register_2_type_indicators.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        cpu_general_purpose_register_grid16x16_type_indicators.get_outputs(
            type_indicator_bus.get_bus_current_data(), gp_address_bus.get_bus_current_data()[-4:], ip_dev
        )
        cpu_stack_data_register_type_indicator.get_outputs(type_indicator_bus.get_bus_current_data(), ip_dev)
        system_memory_type_indicator.get_outputs(
            type_indicator_bus.get_bus_current_data(), address_bus.get_bus_current_data(), ip_dev
        )
