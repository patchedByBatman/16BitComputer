from CPU.control_unit import *

cu = ControlUnit()

for i in range(86):
    print(hex(i), cu.__gen_op_device_byte_code([int(j) for j in format(i, "08b")]))