from imports.general_imports import *
from imports.gates.allGates import *
from imports.combinational_logic.logic import *
from imports.combinational_logic.data_manipulative import *
from imports.combinational_logic.arithmetic import *
from imports.circuit import *
from CPU.cpu_regs import *
from CPU.ALU import *

"""
____________________________________________________________
sel_l | read_write_bar |        state
------------------------------------------------------------
    0 |             0  | op = hi_z : ip = d_in (store data)
    0 |             1  | op = data : ip = none (retrieve)
    1 |             0  | op = hi_z : ip = none (none)
    1 |             1  | op = hi_z : ip = none (none)
------------------------------------------------------------
"""
"""
control_vars order:
    cpu_regs and MEMORY: for each [sel_l, read_write_bar]               
        0) cpu_A_register
        1) cpu_A_register_type_indicators
        2) cpu_B_register
        3) cpu_B_register_type_indicators
        4) cpu_C_register
        5) cpu_C_register_type_indicators
        6) cpu_D_register
        7) cpu_D_register_type_indicators

        8) cpu_memory_address_register_1
        9) cpu_memory_address_register_2
       10) cpu_memory_data_register_1
       11) cpu_memory_data_register_2
       12) cpu_general_purpose_register_grid16x16
       13) cpu_general_purpose_register_grid16x16_type_indicators
       14) cpu_program_counter_register
       15) cpu_instruction_register
       16) cpu_stack_pointer_register
       17) cpu_stack_data_register
       18) cpu_stack_data_register_type_indicator
       19) cpu_flag_register

       20) system_memory
       21) system_memory_type_indicator

    ALU: for each [read_to_bus, dont_care]
       22) ADD word_adder_ckt
       23) INC word_adder_ckt
       24) DINC word_adder_ckt
       25) SUB word_subtractor_ckt
       26) DEC word_subtractor_ckt
       27) DDEC word_subtractor_ckt
       28) MUL word_multiplier_ckt
       29) DBL word_multiplier_ckt
       30) DIV word_divider_ckt
       31) HALF word_divider_ckt
"""


class ControlUnit(Circuit):
    def __init__(self):
        super().__init__()
        self.control_vars = [[1, 1] for i in range(32)]
        self.alu = ALU()
        self.change_bus_data = 0

    def __clear_control_vars(self):
        self.control_vars = [[1, 1] for i in range(32)]

    def __gen_reg_a_instructions(self, op_code):
        # a needs to be in i/p state: code : [0, 0]
        load_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_b_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        transfer_c_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )

        # a needs to be in o/p state: code : [0, 1]
        store_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                op_code[3],  # 1
                op_code[4],  # 1
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )
        transfer_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        # todo make sure for the others the order is o/p and then i/p
        # todo implement exchange logic later
        # a needs to be in i/p and then in o/p state : code : [0, 0] --> [0, 1]
        x_chg_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        x_chg_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        x_chg_a_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )

        self.control_vars[0][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[0][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        self.control_vars[1][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[1][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        if not self.control_vars[0][0] and self.control_vars[0][1]:
            self.change_bus_data = 1
        return [
            self.control_vars[0][0],
            self.control_vars[0][1],
            self.control_vars[1][0],
            self.control_vars[1][1]
        ]

    def __gen_reg_b_instructions(self, op_code):
        # b needs to be in i/p state: code : [0, 0]
        load_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        transfer_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )

        # b needs to be in o/p state: code : [0, 1]
        store_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                op_code[3],  # 1
                op_code[4],  # 1
                op_code[5],  # 1
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        transfer_b_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )

        # todo make sure for the others the order is o/p and then i/p
        # todo implement exchange logic later
        # b needs to be in o/p and then in i/p state : code : [0, 1] --> [0, 0]
        x_chg_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        x_chg_b_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        x_chg_b_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )

        self.control_vars[2][0] = nor_gate.get_output(
            [
                load_b,
                transfer_b_a,
                store_b,
                transfer_a_b
            ]
        )
        self.control_vars[2][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_b,
                        transfer_a_b
                    ]
                ),
                or_gate.get_output(
                    [
                        store_b,
                        transfer_b_a
                    ]
                )
            ]
        )
        self.control_vars[3][0] = nor_gate.get_output(
            [
                load_b,
                transfer_b_a,
                store_b,
                transfer_a_b
            ]
        )
        self.control_vars[3][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_b,
                        transfer_a_b
                    ]
                ),
                or_gate.get_output(
                    [
                        store_b,
                        transfer_b_a
                    ]
                )
            ]
        )
        if not self.control_vars[2][0] and self.control_vars[2][1]:
            self.change_bus_data = 1
        return [
            self.control_vars[2][0],
            self.control_vars[2][1],
            self.control_vars[3][0],
            self.control_vars[3][1]
        ]

    def __gen_reg_c_instructions(self, op_code):
        # c needs to be in i/p state: code : [0, 0]
        load_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )
        transfer_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_d_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )

        # c needs to be in o/p state: code : [0, 1]
        store_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                op_code[3],  # 1
                op_code[4],  # 1
                op_code[5],  # 1
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )
        transfer_c_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        transfer_c_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )

        # todo make sure for the others the order is o/p and then i/p
        # todo implement exchange logic later
        # c needs to be in o/p and then in i/p state : code : [0, 1] --> [0, 0]
        x_chg_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        x_chg_c_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                op_code[5],  # 1
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        # c needs to be in i/p and then in o/p state : code : [0, 0] --> [0, 1]
        x_chg_b_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )

        self.control_vars[4][0] = nor_gate.get_output(
            [
                load_c,
                transfer_a_c,
                transfer_d_c,
                store_c,
                transfer_c_a,
                transfer_c_d
            ]
        )
        self.control_vars[4][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_c,
                        transfer_a_c,
                        transfer_d_c
                    ]
                ),
                or_gate.get_output(
                    [
                        store_c,
                        transfer_c_a,
                        transfer_c_d
                    ]
                )
            ]
        )
        self.control_vars[5][0] = nor_gate.get_output(
            [
                load_c,
                transfer_a_c,
                transfer_d_c,
                store_c,
                transfer_c_a,
                transfer_c_d
            ]
        )
        self.control_vars[5][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_c,
                        transfer_a_c,
                        transfer_d_c
                    ]
                ),
                or_gate.get_output(
                    [
                        store_c,
                        transfer_c_a,
                        transfer_c_d
                    ]
                )
            ]
        )
        if not self.control_vars[4][0] and self.control_vars[4][1]:
            self.change_bus_data = 1
        return [
            self.control_vars[4][0],
            self.control_vars[4][1],
            self.control_vars[5][0],
            self.control_vars[5][1]
        ]

    def __gen_reg_d_instructions(self, op_code):
        # d needs to be in i/p state: code : [0, 0]
        load_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        transfer_c_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )

        # d needs to be in o/p state: code : [0, 1]
        store_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        transfer_d_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )

        # todo make sure for the others the order is o/p and then i/p
        # todo implement exchange logic later
        # d needs to be in o/p and then in i/p state : code : [0, 1] --> [0, 0]
        x_chg_a_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )
        # d needs to be in i/p and then in o/p state : code : [0, 0] --> [0, 1]
        x_chg_b_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        x_chg_c_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                op_code[5],  # 1
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )

        self.control_vars[6][0] = nor_gate.get_output(
            [
                load_d,
                transfer_c_d,
                store_d,
                transfer_d_c
            ]
        )
        self.control_vars[6][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_d,
                        transfer_c_d
                    ]
                ),
                or_gate.get_output(
                    [
                        store_d,
                        transfer_d_c
                    ]
                )
            ]
        )
        self.control_vars[7][0] = nor_gate.get_output(
            [
                load_d,
                transfer_c_d,
                store_d,
                transfer_d_c
            ]
        )
        self.control_vars[7][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_d,
                        transfer_c_d
                    ]
                ),
                or_gate.get_output(
                    [
                        store_d,
                        transfer_d_c
                    ]
                )
            ]
        )
        if not self.control_vars[6][0] and self.control_vars[6][1]:
            self.change_bus_data = 1
        return [
            self.control_vars[6][0],
            self.control_vars[6][1],
            self.control_vars[7][0],
            self.control_vars[7][1]
        ]

    def __gen_memory_address_register_1_H_instructions(self, op_code):
        # a needs to be in i/p state: code : [0, 0]
        load_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_b_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        transfer_c_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )

        # a needs to be in o/p state: code : [0, 1]
        store_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                op_code[3],  # 1
                op_code[4],  # 1
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )
        transfer_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        # todo make sure for the others the order is o/p and then i/p
        # todo implement exchange logic later
        # a needs to be in i/p and then in o/p state : code : [0, 0] --> [0, 1]
        x_chg_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        x_chg_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        x_chg_a_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )

        self.control_vars[0][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[0][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        self.control_vars[1][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[1][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        if not self.control_vars[0][0] and self.control_vars[0][1]:
            self.change_bus_data = 1
        return [
            self.control_vars[0][0],
            self.control_vars[0][1],
            self.control_vars[1][0],
            self.control_vars[1][1]
        ]

    def __gen_memory_address_register_1_L_instructions(self, op_code):
        # a needs to be in i/p state: code : [0, 0]
        load_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_b_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        transfer_c_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )

        # a needs to be in o/p state: code : [0, 1]
        store_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                op_code[3],  # 1
                op_code[4],  # 1
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )
        transfer_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        # todo make sure for the others the order is o/p and then i/p
        # todo implement exchange logic later
        # a needs to be in i/p and then in o/p state : code : [0, 0] --> [0, 1]
        x_chg_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        x_chg_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        x_chg_a_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )

        self.control_vars[0][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[0][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        self.control_vars[1][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[1][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        if not self.control_vars[0][0] and self.control_vars[0][1]:
            self.change_bus_data = 1
        return [
            self.control_vars[0][0],
            self.control_vars[0][1],
            self.control_vars[1][0],
            self.control_vars[1][1]
        ]

    def __gen_memory_address_register_2_H_instructions(self, op_code):
        # a needs to be in i/p state: code : [0, 0]
        load_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_b_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        transfer_c_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )

        # a needs to be in o/p state: code : [0, 1]
        store_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                op_code[3],  # 1
                op_code[4],  # 1
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )
        transfer_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        # todo make sure for the others the order is o/p and then i/p
        # todo implement exchange logic later
        # a needs to be in i/p and then in o/p state : code : [0, 0] --> [0, 1]
        x_chg_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        x_chg_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        x_chg_a_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )

        self.control_vars[0][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[0][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        self.control_vars[1][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[1][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        if not self.control_vars[0][0] and self.control_vars[0][1]:
            self.change_bus_data = 1
        return [
            self.control_vars[0][0],
            self.control_vars[0][1],
            self.control_vars[1][0],
            self.control_vars[1][1]
        ]

    def __gen_memory_address_register_2_L_instructions(self, op_code):
        # a needs to be in i/p state: code : [0, 0]
        load_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_b_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        transfer_c_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )

        # a needs to be in o/p state: code : [0, 1]
        store_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                op_code[3],  # 1
                op_code[4],  # 1
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )
        transfer_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        # todo make sure for the others the order is o/p and then i/p
        # todo implement exchange logic later
        # a needs to be in i/p and then in o/p state : code : [0, 0] --> [0, 1]
        x_chg_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        x_chg_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        x_chg_a_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )

        self.control_vars[0][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[0][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        self.control_vars[1][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[1][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        if not self.control_vars[0][0] and self.control_vars[0][1]:
            self.change_bus_data = 1
        return [
            self.control_vars[0][0],
            self.control_vars[0][1],
            self.control_vars[1][0],
            self.control_vars[1][1]
        ]

    def __gen_general_purpose_reg_instructions(self, op_code):
        # a needs to be in i/p state: code : [0, 0]
        load_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_b_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        transfer_c_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )

        # a needs to be in o/p state: code : [0, 1]
        store_a = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                not_gate.get_output(op_code[2]),  # 0
                op_code[3],  # 1
                op_code[4],  # 1
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        transfer_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )
        transfer_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        # todo make sure for the others the order is o/p and then i/p
        # todo implement exchange logic later
        # a needs to be in i/p and then in o/p state : code : [0, 0] --> [0, 1]
        x_chg_a_b = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        x_chg_a_c = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        x_chg_a_d = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )

        self.control_vars[0][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[0][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        self.control_vars[1][0] = nor_gate.get_output(
            [
                load_a,
                transfer_b_a,
                transfer_c_a,
                store_a,
                transfer_a_b,
                transfer_a_c
            ]
        )
        self.control_vars[1][1] = and_gate.get_output(
            [
                nor_gate.get_output(
                    [
                        load_a,
                        transfer_b_a,
                        transfer_c_a
                    ]
                ),
                or_gate.get_output(
                    [
                        store_a,
                        transfer_a_b,
                        transfer_a_c
                    ]
                )
            ]
        )
        if not self.control_vars[0][0] and self.control_vars[0][1]:
            self.change_bus_data = 1
        return [
            self.control_vars[0][0],
            self.control_vars[0][1],
            self.control_vars[1][0],
            self.control_vars[1][1]
        ]

    def __gen_ADD_instructions(self, op_code):
        self.control_vars[22][0] = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                not_gate.get_output(op_code[3]),  # 0
                op_code[4],  # 1
                op_code[5],  # 1
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )
        if self.control_vars[22][0]:
            self.change_bus_data = 1
        return self.control_vars[22][0]

    def __gen_SUB_instructions(self, op_code):
        self.control_vars[25][0] = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                op_code[3],  # 1
                not_gate.get_output(op_code[4]),  # 0
                not_gate.get_output(op_code[5]),  # 0
                op_code[6],  # 1
                not_gate.get_output(op_code[7])  # 0
            ]
        )
        if self.control_vars[25][0]:
            self.change_bus_data = 1
        return self.control_vars[25][0]

    def __gen_MUL_instructions(self, op_code):
        self.control_vars[28][0] = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                op_code[3],  # 1
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                not_gate.get_output(op_code[6]),  # 0
                op_code[7]  # 1
            ]
        )
        if self.control_vars[28][0]:
            self.change_bus_data = 1
        return self.control_vars[28][0]

    def __gen_DIV_instructions(self, op_code):
        self.control_vars[30][0] = and_gate.get_output(  # 1 if
            [
                not_gate.get_output(op_code[0]),  # 0
                not_gate.get_output(op_code[1]),  # 0
                op_code[2],  # 1
                op_code[3],  # 1
                not_gate.get_output(op_code[4]),  # 0
                op_code[5],  # 1
                op_code[6],  # 1
                op_code[7]  # 1
            ]
        )
        if self.control_vars[30][0]:
            self.change_bus_data = 1
        return self.control_vars[30][0]

    def main_loop(self, op_code):
        # generating control_vars
        self.__clear_control_vars()
        self.__gen_reg_a_instructions(op_code)
        self.__gen_reg_b_instructions(op_code)
        self.__gen_reg_c_instructions(op_code)
        self.__gen_reg_d_instructions(op_code)
        self.__gen_ADD_instructions(op_code)
        self.__gen_SUB_instructions(op_code)
        self.__gen_MUL_instructions(op_code)
        self.__gen_DIV_instructions(op_code)
        if self.change_bus_data:
            data_bus.get_outputs(
                [
                    # todo add and sub return tuples fix this so that you need no indexing
                    self.alu.add(self.control_vars[22][0])[0],
                    # self.alu.inc(self.control_vars[23][0]),
                    self.alu.sub(self.control_vars[25][0])[0]
                    # self.alu.dec(self.control_vars[26][0]),
                    # self.alu.mul(self.control_vars[28][0]),
                    # self.alu.div(self.control_vars[30][0])
                ]
            )
        self.change_bus_data = False

        # forwarding control_vars
        cpu_A_register.get_outputs(data_bus.get_bus_current_data(), *self.control_vars[0])
        cpu_A_register_type_indicators.get_outputs(data_bus.get_bus_current_data(), *self.control_vars[1])
        cpu_B_register.get_outputs(data_bus.get_bus_current_data(), *self.control_vars[2])
        cpu_B_register_type_indicators.get_outputs(data_bus.get_bus_current_data(), *self.control_vars[3])
        cpu_C_register.get_outputs(data_bus.get_bus_current_data(), *self.control_vars[4])
        cpu_C_register_type_indicators.get_outputs(data_bus.get_bus_current_data(), *self.control_vars[5])
        cpu_D_register.get_outputs(data_bus.get_bus_current_data(), *self.control_vars[6])
        cpu_D_register_type_indicators.get_outputs(data_bus.get_bus_current_data(), *self.control_vars[7])

        # data_bus.float_bus_data()


