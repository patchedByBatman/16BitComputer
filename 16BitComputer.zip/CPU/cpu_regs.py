from imports.general_imports import *
from imports.gates.allGates import *
from imports.circuit import *
from imports.combinational_logic.logic import *
from imports.combinational_logic.data_manipulative import *
from imports.combinational_logic.arithmetic import *
from sequential_logic.memory_elements import *
from sequential_logic.latches_ffs import *
from sequential_logic.counters import *
from sequential_logic.state_machines import *

"""
abbreviations:
KW = Kilo-Words

Notes:
====> the _type_indicator memories hold the bits that indicate the data type of corresponding register or memory data
        the _type_indicator hold 3 bits per data:
        they are as follows:
        sign_bit | B1 | B0 | type_indicated
        -----------------------------------
            0    |  0 |  0 |  +ve int 
            0    |  0 |  1 |  +ve float 
            0    |  1 |  0 |  **char
            0    |  1 |  1 |  **SPECIAL_DATA 
            1    |  0 |  0 |  -ve int 
            1    |  0 |  1 |  -ve float 
            1    |  1 |  0 |  **char 
            1    |  1 |  1 |  **SPECIAL_DATA
        -------------------------------------
        ** => neglect (sign_bit & B0 bit) check if encountered B1:1 
"""


# create A, B, C, D registers
cpu_A_register = MemoryArray(16, byte_generator(0x00))
cpu_A_register_type_indicators = MemoryArray(3, byte_generator(0x00))
cpu_B_register = MemoryArray(16, byte_generator(0x02))
cpu_B_register_type_indicators = MemoryArray(3, byte_generator(0x02))
cpu_C_register = MemoryArray(16, byte_generator(0x04))
cpu_C_register_type_indicators = MemoryArray(3, byte_generator(0x04))
cpu_D_register = MemoryArray(16, byte_generator(0x06))
cpu_D_register_type_indicators = MemoryArray(3, byte_generator(0x06))

# create memory_address_register, memory_data_register,
# general_purpose_register_grid, program_counter,
# instruction_register, stack_pointer_register,
# stack_data_register, flag_register registers
cpu_memory_address_register_1 = [MemoryArray(8, byte_generator(0x08)), MemoryArray(8, byte_generator(0xF8))]
cpu_memory_address_register_2 = [MemoryArray(8, byte_generator(0x0A)), MemoryArray(8, byte_generator(0xFA))]
cpu_memory_data_register_1 = MemoryArray(16, byte_generator(0x0C))
cpu_memory_data_register_1_type_indicators = MemoryArray(3, byte_generator(0x0C))
cpu_memory_data_register_2 = MemoryArray(16, byte_generator(0x0E))
cpu_memory_data_register_2_type_indicators = MemoryArray(3, byte_generator(0x0E))
cpu_general_purpose_register_grid16x16 = MemoryNxMGrid(16, 16, byte_generator(0x10))
cpu_general_purpose_register_grid16x16_type_indicators = MemoryNxMGrid(16, 3, byte_generator(0x10))
cpu_program_counter_register = MemoryArray(16, byte_generator(0x12))
cpu_instruction_register = MemoryArray(16, byte_generator(0x14))
cpu_stack_pointer_register = MemoryArray(16, byte_generator(0x16))
cpu_stack_data_register = MemoryArray(16, byte_generator(0x18))
cpu_stack_data_register_type_indicator = MemoryArray(3, byte_generator(0x18))
# todo assign flag_bits and positions
cpu_flag_register = MemoryArray(16, byte_generator(0x1A))

# create system_memory 64KB
"""
actual memory distribution when system_memory is 64KW
from address 0 to 10239 => programme memory (10KW)
from address 10240 to 11263 => Stack (1KW)
from address 11264 to 65535 => Data (53KW)

optimised memory distribution for faster simulation (limiting memory to 200W)
from address 0 to 139 => programme memory (140W)
from address 140 to 149 => Stack (10W)
from address 150 to 199 => Data (50W)
"""
"""
actual system_memory declaration
system_memory = MemoryNxMGrid(65536, 16, byte_generator(0x1C))
system_memory_type_indicator = MemoryNxMGrid(65536, 3, byte_generator(0x1C))
"""

system_memory = MemoryNxMGrid(200, 16, byte_generator(0x1C))
system_memory_type_indicator = MemoryNxMGrid(200, 3, byte_generator(0x1C))

# create ALU
# got word==> adder/subtractor/multiplier/divider from import section
# got comparators from import section

# setting proper initial data in cpu registers
"""
actual settings
cpu_memory_address_register_1.get_outputs(word_generator(11264), byte_generator(0x09))
cpu_program_counter_register.get_outputs(word_generator(0), byte_generator(0x13))
cpu_stack_pointer_register.get_outputs(word_generator(10240), byte_generator(0x17))
"""
cpu_memory_address_register_1[0].get_outputs(word_generator(150)[:8], byte_generator(0x09))
cpu_memory_address_register_1[1].get_outputs(word_generator(150)[8:], byte_generator(0xF9))
cpu_program_counter_register.get_outputs(word_generator(0), byte_generator(0x13))
cpu_stack_pointer_register.get_outputs(word_generator(140), byte_generator(0x17))
