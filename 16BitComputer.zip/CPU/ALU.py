from imports.general_imports import *
from imports.gates.allGates import *
from imports.combinational_logic.logic import *
from imports.combinational_logic.data_manipulative import *
from imports.combinational_logic.arithmetic import *
from CPU.cpu_regs import *
from imports.circuit import *


class ALU(Circuit):
    def __init__(self):
        super().__init__()

    def address_check(self, device_id, device_selection_data):
        return and_gate.get_output(
            [
                xnor_gate.get_output([bit1, bit2])
                for bit1, bit2 in zip(device_selection_data[:-1] + [0], device_id)
            ]
        )

    def add(self, device_selection_data):
        address_match_found = self.address_check(word_adder_ckt.device_id, device_selection_data)
        read_words = and_gate.get_output([not_gate.get_output(device_selection_data[-1]), address_match_found])
        write_to_bus = and_gate.get_output(
            [
                not_gate.get_output(device_selection_data[-1]),
                address_match_found
            ]
        )
        result = [[None]*16, None]
        if read_words:  # reg_a and reg_b are always connected to ALU, this is done just for code optimization
            result = word_adder_ckt.get_outputs(
                    cpu_A_register.get_outputs(zeros, byte_generator(0x00)),
                    cpu_B_register.get_outputs(zeros, byte_generator(0x02)), 0)
        return tri_state_array_ckt.get_outputs(result[0], write_to_bus), \
               tri_state_cell_ckt.get_output(result[1], write_to_bus)

    # todo inc function should be implemented without zeros using combination of op_codes
    def inc(self, write_to_bus):
        result = word_adder_ckt.get_outputs(cpu_A_register.get_outputs(zeros, 0, 1), zeros, 1)
        return tri_state_array_ckt.get_outputs(result[0], write_to_bus), \
               tri_state_cell_ckt.get_output(result[1], write_to_bus)

    # todo dinc function should be implemented without word_gen using combination of op_codes
    def dinc(self, write_to_bus):
        result = word_adder_ckt.get_outputs(cpu_A_register.get_outputs(zeros, 0, 1), word_generator(2), 0)
        return tri_state_array_ckt.get_outputs(result[0], write_to_bus), \
               tri_state_cell_ckt.get_output(result[1], write_to_bus)

    def sub(self, device_selection_data):
        address_match_found = self.address_check(word_subtractor_ckt.device_id, device_selection_data)
        read_words = and_gate.get_output([not_gate.get_output(device_selection_data[-1]), address_match_found])
        write_to_bus = and_gate.get_output(
            [
                not_gate.get_output(device_selection_data[-1]),
                address_match_found
            ]
        )
        result = [[None]*16, None]
        if read_words:  # reg_a and reg_b are always connected to ALU, this is done just for code optimization
            result = word_subtractor_ckt.get_outputs(
                cpu_A_register.get_outputs(zeros, byte_generator(0x00)),
                cpu_B_register.get_outputs(zeros, byte_generator(0x02))
            )
        return tri_state_array_ckt.get_outputs(result[0], write_to_bus), \
               tri_state_cell_ckt.get_output(result[1], write_to_bus)

    # todo dec function should be implemented without word_gen using combination of op_codes
    def dec(self, write_to_bus):
        result = word_subtractor_ckt.get_outputs(cpu_A_register.get_outputs(zeros, 0, 1), word_generator(1))
        return tri_state_array_ckt.get_outputs(result[0], write_to_bus), \
               tri_state_cell_ckt.get_output(result[1], write_to_bus)

    # todo ddec function should be implemented without word_gen using combination of op_codes
    def ddec(self, write_to_bus):
        result = word_subtractor_ckt.get_outputs(cpu_A_register.get_outputs(zeros, 0, 1), word_generator(2))
        return tri_state_array_ckt.get_outputs(result[0], write_to_bus), \
               tri_state_cell_ckt.get_output(result[1], write_to_bus)

    def mul(self, device_selection_data):
        address_match_found = self.address_check(word_multiplier_ckt.device_id, device_selection_data)
        read_words = and_gate.get_output([not_gate.get_output(device_selection_data[-1]), address_match_found])
        write_to_bus = and_gate.get_output(
            [
                not_gate.get_output(device_selection_data[-1]),
                address_match_found
            ]
        )
        result = [[None]*16, None]
        if read_words:  # reg_a and reg_b are always connected to ALU, this is done just for code optimization
            result = word_multiplier_ckt.get_outputs(
                cpu_A_register.get_outputs(zeros, byte_generator(0x00)),
                cpu_B_register.get_outputs(zeros, byte_generator(0x02))
            )
        return tri_state_array_ckt.get_outputs(result[0], write_to_bus), \
               tri_state_cell_ckt.get_output(result[1], write_to_bus)

    # todo dbl function should be implemented without word_gen using combination of op_codes
    def dbl(self, write_to_bus):
        return tri_state_array_ckt.get_outputs(
            word_multiplier_ckt.get_outputs(cpu_A_register.get_outputs(zeros, 0, 1), word_generator(2)), write_to_bus
        )

    def div(self, device_selection_data):
        address_match_found = self.address_check(word_divider_ckt.device_id, device_selection_data)
        read_words = and_gate.get_output([not_gate.get_output(device_selection_data[-1]), address_match_found])
        write_to_bus = and_gate.get_output(
            [
                not_gate.get_output(device_selection_data[-1]),
                address_match_found
            ]
        )
        result = [[None] * 16, None]
        if read_words:  # reg_a and reg_b are always connected to ALU, this is done just for code optimization
            result = word_divider_ckt.get_outputs(
                cpu_A_register.get_outputs(zeros, byte_generator(0x00)),
                cpu_B_register.get_outputs(zeros, byte_generator(0x02))
            )
        return tri_state_array_ckt.get_outputs(result[0], write_to_bus), \
               tri_state_cell_ckt.get_output(result[1], write_to_bus)

    # todo half function should be implemented without word_gen using combination of op_codes
    def half(self, write_to_bus):
        return tri_state_array_ckt.get_outputs(
            word_divider_ckt.get_outputs(cpu_A_register.get_outputs(zeros, 0, 1), word_generator(2)), write_to_bus
        )

    def cmp(self, device_selection_data):
        address_match_found = self.address_check(word_comparator_ckt.device_id, device_selection_data)
        read_words = and_gate.get_output([not_gate.get_output(device_selection_data[-1]), address_match_found])
        write_to_bus = and_gate.get_output(
            [
                not_gate.get_output(device_selection_data[-1]),
                address_match_found
            ]
        )
        result = [None]*16
        if read_words:  # reg_a and reg_b are always connected to ALU, this is done just for code optimization
            result = word_comparator_ckt.get_outputs(
                cpu_A_register.get_outputs(zeros, byte_generator(0x00)),
                cpu_B_register.get_outputs(zeros, byte_generator(0x02))
            )
        return tri_state_array_ckt.get_outputs(result, write_to_bus)

    def bcmp(self, device_selection_data):
        address_match_found = self.address_check(bit_comparator_ckt.device_id, device_selection_data)
        read_words = and_gate.get_output([not_gate.get_output(device_selection_data[-1]), address_match_found])
        write_to_bus = and_gate.get_output(
            [
                not_gate.get_output(device_selection_data[-1]),
                address_match_found
            ]
        )
        result = [None]*16
        if read_words:  # reg_a and reg_b are always connected to ALU, this is done just for code optimization
            result = bit_comparator_ckt.get_outputs(
                cpu_A_register.get_outputs(zeros, byte_generator(0x00)),
                cpu_B_register.get_outputs(zeros, byte_generator(0x02))
            )
        return tri_state_array_ckt.get_outputs(result, write_to_bus)