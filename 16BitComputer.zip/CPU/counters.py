from sequential_logic.counters import *
from imports.general_imports import *
from CPU.cpu_regs import *


class CPUCounter:
    def __init__(self, max_count):
        self.adder = WordAdder("cpu_counter")
        self.cpu_program_counter_register_current_state = cpu_program_counter_register.get_outputs(
            zeros,
            byte_generator(0x12)
        )

    def get_outputs(self):
        self.cpu_program_counter_register_current_state = cpu_program_counter_register.get_outputs(
            zeros, byte_generator(0x12)
        )
        halt_bit = cpu_flag_register.get_outputs(zeros, byte_generator(0x1A))[15 - 3]
        halt_bit = not_gate.get_output(halt_bit)
        cpu_program_counter_register.get_outputs(
            self.adder.get_outputs(
                self.cpu_program_counter_register_current_state,
                zeros,
                1
            )[0],
            [and_gate.get_output([en_bit, halt_bit]) for en_bit in byte_generator(0x13)]
        )