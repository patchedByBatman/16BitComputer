"""
control_unit instruction_set:
===>> this architecture consists of an 8-bit instruction set
(optimizations are not a priority)
**********************instruction pattern************************
    _______________________________________
    bits | 15 <--till--> 8 | 7 <--till--> 0
    ---------------------------------------
         | [ instruction ] | [ data_byte ]
    the data_byte can be upper/lower byte of an address/data word
*****************************************************************
************************************data transfer instruction set**************************************
_______________________________________________________________________________________________________
type: | instruction | opp_code | HEX_CODE |        description
-------------------------------------------------------------------------------------------------------
LOAD  | LDAA        | 00000001 |   01H    | load value @cpu_memory_address_register_1 to cpu_A_register
 MEM  |             |          |          | also loads the corresponding type_indicator bits to
  TO  |             |          |          | cpu_A_register_type_indicators
 REG  -------------------------------------------------------------------------------------------------
      | LDAB        | 00000010 |   02H    | load value @cpu_memory_address_register_1 to cpu_B_register
      |             |          |          | also loads the corresponding type_indicator bits to
      |             |          |          | cpu_B_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | LDAC        | 00000011 |   03H    | load value @cpu_memory_address_register_1 to cpu_C_register
      |             |          |          | also loads the corresponding type_indicator bits to
      |             |          |          | cpu_C_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | LDAD        | 00000100 |   04H    | load value @cpu_memory_address_register_1 to cpu_D_register
      |             |          |          | also loads the corresponding type_indicator bits to
      |             |          |          | cpu_D_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | LDAMA1H     | 00000101 |   05H    | load [data_byte (ADDRESS)][BITS 7 TO 0] OF INSTRUCTION to
      |             |          |          | HIGH_BYTE of cpu_memory_address_register_1
      -------------------------------------------------------------------------------------------------
      | LDAMA1L     | 00000110 |   06H    | load [data_byte (ADDRESS)][BITS 7 TO 0] OF INSTRUCTION to
      |             |          |          | LOW_BYTE of cpu_memory_address_register_1
      -------------------------------------------------------------------------------------------------
      | LDAMA2H     | 00000111 |   07H    | load [data_byte (ADDRESS)][BITS 7 TO 0] OF INSTRUCTION to
      |             |          |          | HIGH_BYTE of cpu_memory_address_register_2
      -------------------------------------------------------------------------------------------------
      | LDAMA2L     | 00001000 |   08H    | load [data_byte (ADDRESS)][BITS 7 TO 0] OF INSTRUCTION to
      |             |          |          | LOW_BYTE of cpu_memory_address_register_2
      -------------------------------------------------------------------------------------------------
      | LDAGP[0-15] | 00001001 | [09-18]H | load value @cpu_memory_address_register_1 to GIVEN
      |             |          |          | cpu_general_purpose_register_grid16x16[0-15]
      | EX: LDAGP0  |    TO    |          | also loads the corresponding type_indicator bits to
      |     LDAGP1  | 00011000 |          | CORRESPONDING cpu_general_purpose_register_grid16x16
      -------------------------------------------------------------------------------------------------
      | LDASP       | 00011001 |   19H    | load ADDRESS @cpu_memory_address_register_1 to
      |             |          |          | cpu_stack_pointer_register
      -------------------------------------------------------------------------------------------------
      | LDAFR       | 00011010 |   1AH    | load value @cpu_memory_address_register_1 to
      |             |          |          | cpu_flag_register
      |             |          |          | WARNING: DON'T USE THIS, IT MAY CORRUPT NEEDED FLAG HISTORY
      -------------------------------------------------------------------------------------------------
      | LDAF        | 00011011 |   1BH    | load value @cpu_memory_address_register_1 to
      |             |          |          | @cpu_memory_address_register_2
      |             |          |          | also loads the corresponding type_indicator bits to
      |             |          |          | TYPE_INDICATOR_BITS@cpu_memory_address_register_2
      -------------------------------------------------------------------------------------------------
      | LDAR        | 00011100 |   1CH    | load value @cpu_memory_address_register_2 to
      |             |          |          | @cpu_memory_address_register_1
      |             |          |          | also loads the corresponding type_indicator bits to
      |             |          |          | TYPE_INDICATOR_BITS@cpu_memory_address_register_1
-------------------------------------------------------------------------------------------------------
STORE | STAA        | 00011101 |   1DH    | load cpu_A_register to @cpu_memory_address_register_1
  REG |             |          |          | also loads cpu_A_register_type_indicators bits to
   TO |             |          |          | type_indicators@cpu_memory_address_register_1
  MEM -------------------------------------------------------------------------------------------------
      | STAB        | 00011110 |   1EH    | load cpu_B_register to @cpu_memory_address_register_1
      |             |          |          | also loads cpu_B_register_type_indicators bits to
      |             |          |          | type_indicators@cpu_memory_address_register_1
      -------------------------------------------------------------------------------------------------
      | STAC        | 00011111 |   1FH    | load cpu_C_register to @cpu_memory_address_register_1
      |             |          |          | also loads cpu_C_register_type_indicators bits to
      |             |          |          | type_indicators@cpu_memory_address_register_1
      -------------------------------------------------------------------------------------------------
      | STAD        | 00100000 |   20H    | load cpu_D_register to @cpu_memory_address_register_1
      |             |          |          | also loads cpu_D_register_type_indicators bits to
      |             |          |          | type_indicators@cpu_memory_address_register_1
      -------------------------------------------------------------------------------------------------
      | STAFR       | 00100001 |   21H    | load cpu_flag_register to @cpu_memory_address_register_1
      |             |          |          | also loads SPECIAL_DATA bits [sign_bit : x, B1 : 1, B0 : 1]
      |             |          |          | to type_indicators@cpu_memory_address_register_1
      -------------------------------------------------------------------------------------------------
      | STASP       | 00100010 |   22H    | load cpu_stack_pointer_register to
      |             |          |          | @cpu_memory_address_register_1
      |             |          |          | also loads SPECIAL_DATA bits [sign_bit : x, B1 : 1, B0 : 1]
      |             |          |          | to type_indicators@cpu_memory_address_register_1
-------------------------------------------------------------------------------------------------------
TRANS | TAB         | 00100011 |   23H    | load value in cpu_A_register to cpu_B_register
FER   |             |          |          | also loads the corresponding type_indicator bits from
  REG |             |          |          | cpu_A_register_type_indicators to
   TO |             |          |          | cpu_B_register_type_indicators
  REG -------------------------------------------------------------------------------------------------
      | TBA         | 00100100 |   24H    | load value in cpu_B_register to cpu_A_register
      |             |          |          | also loads the corresponding type_indicator bits from
      |             |          |          | cpu_B_register_type_indicators to
      |             |          |          | cpu_A_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | TAC         | 00100101 |   25H    | load value in cpu_A_register to cpu_C_register
      |             |          |          | also loads the corresponding type_indicator bits from
      |             |          |          | cpu_A_register_type_indicators to
      |             |          |          | cpu_C_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | TCA         | 00100110 |   26H    | load value in cpu_C_register to cpu_A_register
      |             |          |          | also loads the corresponding type_indicator bits from
      |             |          |          | cpu_C_register_type_indicators to
      |             |          |          | cpu_A_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | TCD         | 00100111 |   27H    | load value in cpu_C_register to cpu_D_register
      |             |          |          | also loads the corresponding type_indicator bits from
      |             |          |          | cpu_C_register_type_indicators to
      |             |          |          | cpu_D_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | TDC         | 00101000 |   28H    | load value in cpu_D_register to cpu_C_register
      |             |          |          | also loads the corresponding type_indicator bits from
      |             |          |          | cpu_D_register_type_indicators to
      |             |          |          | cpu_C_register_type_indicators
-------------------------------------------------------------------------------------------------------
X-CHG | XGAB        | 00101001 |   29H    | EXCHANGE DATA B/W
  B/W |             |          |          | [cpu_A_register, cpu_A_register_type_indicators] AND
 REGs |             |          |          | [cpu_B_register, cpu_B_register_type_indicators]
      -------------------------------------------------------------------------------------------------
      | XGAC        | 00101010 |   2AH    | EXCHANGE DATA B/W
      |             |          |          | [cpu_A_register, cpu_A_register_type_indicators] AND
      |             |          |          | [cpu_C_register, cpu_C_register_type_indicators]
      -------------------------------------------------------------------------------------------------
      | XGAD        | 00101011 |   2BH    | EXCHANGE DATA B/W
      |             |          |          | [cpu_A_register, cpu_A_register_type_indicators] AND
      |             |          |          | [cpu_D_register, cpu_D_register_type_indicators]
      -------------------------------------------------------------------------------------------------
      | XGBC        | 00101100 |   2CH    | EXCHANGE DATA B/W
      |             |          |          | [cpu_B_register, cpu_B_register_type_indicators] AND
      |             |          |          | [cpu_C_register, cpu_C_register_type_indicators]
      -------------------------------------------------------------------------------------------------
      | XGBD        | 00101101 |   2DH    | EXCHANGE DATA B/W
      |             |          |          | [cpu_B_register, cpu_B_register_type_indicators] AND
      |             |          |          | [cpu_D_register, cpu_D_register_type_indicators]
      -------------------------------------------------------------------------------------------------
      | XGCD        | 00101110 |   2EH    | EXCHANGE DATA B/W
      |             |          |          | [cpu_C_register, cpu_C_register_type_indicators] AND
      |             |          |          | [cpu_D_register, cpu_D_register_type_indicators]
-------------------------------------------------------------------------------------------------------
******************************************ALU instruction set******************************************
_______________________________________________________________________________________________________
type: | instruction | opp_code | HEX_CODE |        description
-------------------------------------------------------------------------------------------------------
ADD   | ADD         | 00101111 |   2FH    | ADD CONTENTS OF REG_A AND REG_B, STORE THE RESULT IN REG_C
      -------------------------------------------------------------------------------------------------
      | INC         | 00110000 |   30H    | INCREMENT REG_A BY 1, STORE THE RESULT IN REG_C
      -------------------------------------------------------------------------------------------------
      | DINC        | 00110001 |   31H    | INCREMENT REG_A BY 2, STORE THE RESULT IN REG_C
-------------------------------------------------------------------------------------------------------
 SUB  | SUB         | 00110010 |   32H    | SUB CONTENTS OF REG_A AND REG_B, STORE THE RESULT IN REG_C
      -------------------------------------------------------------------------------------------------
      | DEC         | 00110011 |   33H    | DECREMENT REG_A BY 1, STORE THE RESULT IN REG_C
      -------------------------------------------------------------------------------------------------
      | DDEC        | 00110100 |   34H    | DECREMENT REG_A BY 2, STORE THE RESULT IN REG_C
-------------------------------------------------------------------------------------------------------
 MUL  | MUL         | 00110101 |   35H    | [HI-WORD:REG_D][LO-WORD:REG_C] = REG_A*REG_B
      -------------------------------------------------------------------------------------------------
      | DBL         | 00110110 |   36H    | [HI-WORD:REG_D][LO-WORD:REG_C] = REG_A*2
      |             |          |          | NOTE: CAN ALSO USE SHIFT-LEFT BY 1
-------------------------------------------------------------------------------------------------------
 DIV  | DIV         | 00110111 |   37H    | [REMAINDER:REG_D][QUOTIENT:REG_C] = REG_A/REG_B
      -------------------------------------------------------------------------------------------------
      | HALF        | 00111000 |   38H    | [REMAINDER:REG_D][QUOTIENT:REG_C] = REG_A/2
      |             |          |          | NOTE: CAN ALSO USE SHIFT-RIGHT BY 1
-------------------------------------------------------------------------------------------------------
 CMP  | CMP         | 00111001 |   39H    | COMPARE CONTENTS OF REG_A AND REG_B, STORE THE RESULT IN
      |             |          |          | cpu_flag_register BITS[15 TO 7]
      -------------------------------------------------------------------------------------------------
      | G           | 00111010 |   3AH    | COMPARE CONTENTS OF REG_A AND REG_B, STORE THE RESULT IN
      |             |          |          | cpu_flag_register BITS[15 TO 7]
      -------------------------------------------------------------------------------------------------
      | GE          | 00111011 |   3BH    | COMPARE CONTENTS OF REG_A AND REG_B, STORE THE RESULT IN
      |             |          |          | cpu_flag_register BITS[15 TO 7]
      -------------------------------------------------------------------------------------------------
      | L           | 00111100 |   3CH    | COMPARE CONTENTS OF REG_A AND REG_B, STORE THE RESULT IN
      |             |          |          | cpu_flag_register BITS[15 TO 7]
      -------------------------------------------------------------------------------------------------
      | LE          | 00111101 |   3DH    | COMPARE CONTENTS OF REG_A AND REG_B, STORE THE RESULT IN
      |             |          |          | cpu_flag_register BITS[15 TO 7]
      -------------------------------------------------------------------------------------------------
      | EE          | 00111110 |   3EH    | COMPARE CONTENTS OF REG_A AND REG_B, STORE THE RESULT IN
      |             |          |          | cpu_flag_register BITS[15 TO 7]
      -------------------------------------------------------------------------------------------------
      | NE          | 00111111 |   3FH    | COMPARE CONTENTS OF REG_A AND REG_B, STORE THE RESULT IN
      |             |          |          | cpu_flag_register BITS[15 TO 7]
-------------------------------------------------------------------------------------------------------
LOGIC | CLR         | 01000000 |   40H    | CLEARS DATA @cpu_memory_address_register_1
      |             |          |          | also CLEARS
      |             |          |          | type_indicators@cpu_memory_address_register_1
      -------------------------------------------------------------------------------------------------
      | COMP        | 01000001 |   41H    | COMPLEMENTS DATA IN REG_A
      |             |          |          | ALSO COMPLEMENTS
      |             |          |          | type_indicators OF REG_A
      -------------------------------------------------------------------------------------------------
      | TWOS        | 01000010 |   42H    | FINDS TWO'S OF DATA IN REG_A
      |             |          |          | EFFECTS BITS IN
      |             |          |          | type_indicators OF REG_A
      -------------------------------------------------------------------------------------------------
      | AND         | 01000011 |   43H    | ANDs REG_A AND REG_B
      |             |          |          | AND STORES THE RESULT IN
      |             |          |          | REG_C
      -------------------------------------------------------------------------------------------------
      | OR          | 01000100 |   44H    | ORs REG_A AND REG_B
      |             |          |          | AND STORES THE RESULT IN
      |             |          |          | REG_C
      -------------------------------------------------------------------------------------------------
      | XOR         | 01000101 |   45H    | XORs REG_A AND REG_B
      |             |          |          | AND STORES THE RESULT IN
      |             |          |          | REG_C
-------------------------------------------------------------------------------------------------------
 BIT  | BCLR        | 01000110 |   46H    | CLEARS REG_A_th BIT @cpu_memory_address_register_1
      -------------------------------------------------------------------------------------------------
      | BSET        | 01000111 |   47H    | SETS REG_A_th BIT @cpu_memory_address_register_1
      -------------------------------------------------------------------------------------------------
      | GRAY        | 01001000 |   48H    | COMPUTES GRAY_CODE OF REG_A AND STORES RESULT IN REG_C
      -------------------------------------------------------------------------------------------------
      | BAND        | 01001001 |   49H    | BITWISE AND OF REG_A, STORES RESULT IN REG_C
      -------------------------------------------------------------------------------------------------
      | BOR         | 01001010 |   4AH    | BITWISE OR OF REG_A, STORES RESULT IN REG_C
      -------------------------------------------------------------------------------------------------
      | BXOR        | 01001011 |   4BH    | BITWISE XOR OF REG_A, STORES RESULT IN REG_C
-------------------------------------------------------------------------------------------------------
      | JMP         | 01010000 |   50H    | load value in cpu_reg_d to
      |             |          |          | cpu_program_counter_register
      |             |          |          | NOTE: BEFORE USING JMP FIRST: LOAD CURRENT
      |             |          |          | cpu_program_counter_register TO SYS_MEM
      |             |          |          | SECOND: LOAD MEM_1_REG WITH VALID ADDRESS
-------------------------------------------------------------------------------------------------------
      | JZ          | 01010001 |   51H    | JMP IF VALUE IN REG_C IS ZERO
      |             |          |          | NOTE: THE VALUE ZERO IN REG_C CAN BE A RESULT OF ALU
      |             |          |          | ACTION
-------------------------------------------------------------------------------------------------------
      | JNZ         | 01010010 |   52H    | JMP IF VALUE IN REG_C IS NOT ZERO
      |             |          |          | NOTE: THE VALUE ZERO IN REG_C CAN BE A RESULT OF ALU
      |             |          |          | ACTION
-------------------------------------------------------------------------------------------------------
      | JG          | 01010011 |   53H    | JMP IF FLAG_BITS IN FLAG_REG INDICATE '>'
      |             |          |          | NOTE: MIGHT WANT TO USE CMP ON REG_A AND REG_B BEFORE USING
      |             |          |          | JG
-------------------------------------------------------------------------------------------------------
      | JL          | 01010100 |   54H    | JMP IF FLAG_BITS IN FLAG_REG INDICATE '<'
      |             |          |          | NOTE: MIGHT WANT TO USE CMP ON REG_A AND REG_B BEFORE USING
      |             |          |          | JL
-------------------------------------------------------------------------------------------------------
      | STAPC       | 01010101 |   55H    | load ADDRESS IN cpu_program_counter_register to
      |             |          |          | @cpu_memory_address_register_1
      |             |          |          | NOTE: COULD BE USEFUL WHEN USING JMP
-------------------------------------------------------------------------------------------------------
      | NOP         | 01010110 |   56H    | NO OPERATION PERIOD INSTRUCTION
-------------------------------------------------------------------------------------------------------
TRANS | TAD         | 01010111 |   57H    | load value in cpu_A_register to cpu_D_register
FER   |             |          |          | also loads the corresponding type_indicator bits from
REG   |             |          |          | cpu_A_register_type_indicators to
TO    |             |          |          | cpu_D_register_type_indicators
REG   -------------------------------------------------------------------------------------------------
EXTEN | TDA         | 01011000 |   58H    | load value in cpu_D_register to cpu_A_register
 -DED |             |          |          | also loads the corresponding type_indicator bits from
      |             |          |          | cpu_D_register_type_indicators to
      |             |          |          | cpu_A_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | TBC         | 01011001 |   59H    | load value in cpu_B_register to cpu_C_register
      |             |          |          | also loads the corresponding type_indicator bits from
      |             |          |          | cpu_B_register_type_indicators to
      |             |          |          | cpu_C_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | TCB         | 01011010 |   5AH    | load value in cpu_C_register to cpu_B_register
      |             |          |          | also loads the corresponding type_indicator bits from
      |             |          |          | cpu_C_register_type_indicators to
      |             |          |          | cpu_B_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | TBD         | 01011011 |   5BH    | load value in cpu_B_register to cpu_D_register
      |             |          |          | also loads the corresponding type_indicator bits from
      |             |          |          | cpu_B_register_type_indicators to
      |             |          |          | cpu_D_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | TDB         | 01011100 |   5CH    | load value in cpu_D_register to cpu_B_register
      |             |          |          | also loads the corresponding type_indicator bits from
      |             |          |          | cpu_D_register_type_indicators to
      |             |          |          | cpu_B_register_type_indicators
-------------------------------------------------------------------------------------------------------
LOAD  | LDAAGP      | 01011101 |   5DH    | load value @cpu_memory_address_register_2 to cpu_A_register
 MEM  |             |          |          | also loads the corresponding type_indicator bits to
  TO  |             |          |          | cpu_A_register_type_indicators
 REG  -------------------------------------------------------------------------------------------------
EXTEN | LDABGP      | 01011110 |   5EH    | load value @cpu_memory_address_register_2 to cpu_B_register
 -DED |             |          |          | also loads the corresponding type_indicator bits to
      |             |          |          | cpu_B_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | LDACGP      | 01011111 |   5FH    | load value @cpu_memory_address_register_2 to cpu_C_register
      |             |          |          | also loads the corresponding type_indicator bits to
      |             |          |          | cpu_C_register_type_indicators
      -------------------------------------------------------------------------------------------------
      | LDADGP      | 01100000 |   60H    | load value @cpu_memory_address_register_2 to cpu_D_register
      |             |          |          | also loads the corresponding type_indicator bits to
      |             |          |          | cpu_D_register_type_indicators
-------------------------------------------------------------------------------------------------------
STORE | STAAGP      | 01100001 |   61H    | load cpu_A_register to @cpu_memory_address_register_2
  REG |             |          |          | also loads cpu_A_register_type_indicators bits to
   TO |             |          |          | type_indicators@cpu_memory_address_register_2
  MEM -------------------------------------------------------------------------------------------------
EXTEN | STABGP      | 01100010 |   62H    | load cpu_B_register to @cpu_memory_address_register_2
 -DED |             |          |          | also loads cpu_B_register_type_indicators bits to
      |             |          |          | type_indicators@cpu_memory_address_register_2
      -------------------------------------------------------------------------------------------------
      | STACGP      | 01100011 |   63H    | load cpu_C_register to @cpu_memory_address_register_2
      |             |          |          | also loads cpu_C_register_type_indicators bits to
      |             |          |          | type_indicators@cpu_memory_address_register_2
      -------------------------------------------------------------------------------------------------
      | STADGP      | 01100100 |   64H    | load cpu_D_register to @cpu_memory_address_register_2
      |             |          |          | also loads cpu_D_register_type_indicators bits to
      |             |          |          | type_indicators@cpu_memory_address_register_2
-------------------------------------------------------------------------------------------------------
      | HLT         | 00000000 |   00H    | SYSTEM HALT INSTRUCTION
-------------------------------------------------------------------------------------------------------
"""