import numpy as np

########################################################################################################################
# helpful things for programming
# zeros ==> used as a substitute for data retrieval
zeros = [int(0) for i in range(16)]
ones = [int(1) for j in range(16)]


def word_generator(data):
    return [int(i) for i in format(data, "016b")]


def byte_generator(data):
    return [int(i) for i in format(data, "08b")]


def list_to_string(lst):
    s = ""
    for element in lst:
        s = s + str(element)
    return s


def bin_list_to_hex(lst):
    return hex(int("0b" + list_to_string(lst), 2))
########################################################################################################################
