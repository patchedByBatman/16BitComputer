from imports.general_imports import *
from logic_gates.exceptions import Exceptions


class Circuit:
    def __init__(self):
        pass

    def ip_data_check(self, inputs):  # check to see if given data is other than binary
        raise Exceptions.NotBinaryDataException(inputs)

    # overridable methods
    def get_outputs(self, *args):
        pass

    def get_output(self, *args):
        pass
