from combinational_circuits.data_manipulative.demultiplexer import *
from combinational_circuits.data_manipulative.multiplexers import *
from combinational_circuits.data_manipulative.encoders import *
from combinational_circuits.data_manipulative.decoders import *
from combinational_circuits.data_manipulative.tristate import *
from combinational_circuits.data_manipulative.word_bus import *


# de-multiplexers
demux_1to2_ckt = DMUX1To2()
demux_1to4_ckt = DMUX1To4()
demux_1to8_ckt = DMUX1To8()
demux_1to16_ckt = DMUX1To16()
demux_1to32_ckt = DMUX1To32()
demux_1to64_ckt = DMUX1To64()
demux_1to128_ckt = DMUX1To128()

# multiplexers
mux_2to1_ckt = MUX2To1()
mux_4to1_ckt = MUX4To1()
mux_8to1_ckt = MUX8To1()
mux_16to1_ckt = MUX16To1()
mux_32to1_ckt = MUX32To1()
mux_64to1_ckt = MUX64To1()
mux_128to1_ckt = MUX128To1()

# encoders


# decoders


# tristate
tri_state_cell_ckt = TriStateCell()
tri_state_array_ckt = TriStateArray()

# data bus
data_bus = BUS("data_bus")
type_indicator_bus = BUS("type_indicator_bus")
instruction_bus = BUS("instruction_bus")
device_selection_bus = BUS("device_selection_bus")
address_bus = BUS("address_bus")
gp_address_bus = BUS("gp_address_bus")
