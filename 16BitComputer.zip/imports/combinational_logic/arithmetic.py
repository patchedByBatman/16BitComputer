from imports.general_imports import *
from combinational_circuits.arithmetic.adder import *
from combinational_circuits.arithmetic.subtractor import *
from combinational_circuits.arithmetic.multiplier import *
from combinational_circuits.arithmetic.divider import *
from CPU.cpu_regs import *

word_adder_ckt = WordAdder(byte_generator(0x1E))
word_subtractor_ckt = WordSubtractor(byte_generator(0x20))
word_multiplier_ckt = WordMultiplier(byte_generator(0x22))
word_divider_ckt = WordDivider(byte_generator(0x24))
