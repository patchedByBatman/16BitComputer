from combinational_circuits.logic.comparator import *

word_comparator_ckt = WordComparator(byte_generator(0x26))
bit_comparator_ckt = WordComparator(byte_generator(0x28))