from imports.circuit import *


class Clock(Circuit):
    def __init__(self, frequency):
        # just keep this simple
        super().__init__()
        self.frequency = frequency
        self.current_state = 0

    def get_output(self):
        self.current_state = 1 - self.current_state
        return self.current_state


