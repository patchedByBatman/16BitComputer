def spell(number):
    number = str(number)
    number = number[::-1]
    num_in_words = []
    numbers = {
        "ones": "",
        "0": "zero",
        "1": "one",
        "2": "two",
        "3": "three",
        "4": "four",
        "5": "five",
        "6": "six",
        "7": "seven",
        "8": "eight",
        "9": "nine",
        "10": "ten",
        "11": "eleven",
        "12": "twelve",
        "13": "thirteen",
        "14": "fourteen",
        "15": "fifteen",
        "16": "sixteen",
        "17": "seventeen",
        "18": "eighteen",
        "19": "nineteen",
        "20": "twenty",
        "30": "thirty",
        "40": "forty",
        "50": "fifty",
        "60": "sixty",
        "70": "seventy",
        "80": "eighty",
        "90": "ninety",
        "100": "hundred",
        "1000": "thousand",
        "100000": "lakh",
        "10000000": "crore"
    }
    for i in range(0, len(number) - 1, 2):
        if i == 0:
            num_in_words.append(numbers["ones"])
        else:
            num_in_words.append(numbers[str(10**i)])
        num_in_words.append(numbers[number[i]])
        num_in_words.append(numbers[number[i+1] + "0"])

    return " ".join(num_in_words[::-1])

print(spell(12344))
