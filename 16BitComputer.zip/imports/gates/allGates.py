from logic_gates.special_gates import *
from logic_gates.universal_gates import *

# and, or & not gates are instantiated in logic_gates.imports.basic_gates

# universal gates
nand_gate = NAND()
nor_gate = NOR()

# special gates
xor_gate = XOR()
xnor_gate = XNOR()