from logic_gates.basic_logic_gates import *

transistor_gate_low = Transistor(0)
transistor_gate_high = Transistor(1)
and_gate = AND()
or_gate = OR()
not_gate = NOT()
