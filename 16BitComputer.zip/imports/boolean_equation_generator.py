# indicates presence of each boolean variable for each expression 0=not present 1=present
def equation_to_ckt(equation):
    equations = equation.split("+")
    equations = [eq.strip() for eq in equations]
    or_text = "\tor_gate.get_output(\n\t[{}\n\t]\n)"
    and_text = "\t\tand_gate.get_output(\n\t\t\t\t[{}\n\t\t\t\t]\n\t\t),"
    not_text = "\t\tnot_gate.get_output({})"
    code_text = "op_code[{}]"
    vars = "abcdefghzil"
    single_expression = ""
    for equation in equations:
        position = 0
        ckt = ""
        while position <= len(equation):
            if "'" in equation[position:position+2]:
                for i, var in enumerate(vars):
                    if var in equation[position:position+2]:
                        ckt = ckt + "\n\t\t\t{},".format(not_text.format(code_text.format(i)))
                        break
                position = position + 2
            else:
                for i, var in enumerate(vars):
                    if var in equation[position:position+1]:
                        ckt = ckt + "\n\t\t\t\t\t{},".format(code_text.format(i))
                        break
                position = position + 1
        single_expression = single_expression + "\n{}".format(and_text.format(ckt[:-1]))
    return or_text.format(single_expression[:-1])


eq = "a'bc'de'f'g'h' + a'bc'de'f'g'zi'l' + a'bc'de'f'h'z' + a'bc'de'f'gz'il' + a'bc'de'g'h'z'i'l"

print(equation_to_ckt(eq))

