from imports.general_imports import *
from imports.gates.allGates import *
from sequential_logic.latches_ffs import *
from imports.circuit import *
from math import log2, ceil


class Counter(Circuit):
    def __init__(self, max_count):
        super().__init__()
        self.num_d_ffs = ceil(log2(max_count))
        self.d_ff_array = [(DFF(), SRGatedLatch()) for i in range(self.num_d_ffs)]

    def set_initial_state(self, initial_state):
        for i in range(initial_state):
            self.get_outputs(1)
            self.get_outputs(0)

    def get_outputs(self, clock_state):
        # print(clock_state, [dff.get_outputs(0,0) for dff in self.d_ff_array])
        count = []
        en = clock_state
        dff_current_states = [dff[1].get_outputs(0, 0, en)[1] for dff in self.d_ff_array]
        for dff, dff_current_state in zip(self.d_ff_array, dff_current_states):
            op = dff[1].get_outputs(*dff[0].get_outputs(dff_current_state, en), not_gate.get_output(en))
            count.append(op[0])
            en = op[1]
        return not_gate.get_outputs(count[::-1])