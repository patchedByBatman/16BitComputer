import math

from sequential_logic.latches_ffs import *
from sequential_logic.memory_elements import *
from combinational_circuits.data_manipulative.multiplexers import *
from combinational_circuits.data_manipulative.demultiplexer import *
from combinational_circuits.data_manipulative.tristate import *
from imports.clock import *
from sequential_logic.counters import *


def word_generator(data):
    return [int(i) for i in format(data, "016b")]


def byte_generator(data):
    return [int(i) for i in format(data, "08b")]


srac_latch = SRLatchActiveLow()
sr_gated = SRGatedLatch()
jk_ff = JKFF()
d_ff = DFF()
t_ff = TFF()


_2bit = [[1, 1],
         [1, 1],
         [1, 0],
         [0, 1],
         [0, 0]]
_3bit = [[0, 0, 0],
         [0, 0, 1],
         [0, 1, 0],
         [0, 1, 1],
         [1, 0, 0],
         [1, 0, 1],
         [1, 1, 0],
         [1, 1, 1],
         ]
"""
for s, r in _2bit:
    print(srac_latch.get_outputs(s, r))

print("\n\n")
for e, s, r in _3bit:
    print(sr_gated.get_outputs(s, r, e))

print("\n\n")
for e, j, k in _3bit:
    print(jk_ff.get_outputs(j, k, e))

print("\n\n")
for e, d in _2bit:
    print(d_ff.get_outputs(d, e))

print("\n\n")
for e, t in _2bit:
    print(t_ff.get_outputs(t, e))
"""
mux = MUX128To1()
mux2 = MUXNTo1(int(math.log2(128)))
dmux = DMUX1To16()
dmux2 = DMUX1ToN(int(math.log2(65536)))
tri_state_cell_ckt = TriStateCell()
tri_state_ckt = TriStateArray()
memory_cell_ckt = MemoryCell()
memory_array_ckt = MemoryArray(16, byte_generator(0x00))
memory_grid_ckt = MemoryNxMGrid(16, 16, byte_generator(0x02))

clock = Clock(1000)

counter = Counter(10239)
#counter.set_initial_state(7)


#print([int(i) for i in format(13, "0128b")])
#print(mux.get_output([int(i) for i in format(13, "0128b")], [int(i) for i in format(12, "07b")]))
#print(mux2.get_output([int(i) for i in format(13, "0128b")], [int(i) for i in format(12, "07b")]))
#print(dmux.get_output(1, [int(i) for i in format(15, "04b")]))
#print(dmux2.get_output(1, [int(i) for i in format(65535, "016b")]))
#print(tri_state_cell_ckt.get_output(0, 0))
#print(tri_state_ckt.get_outputs([int(i) for i in format(32, "032b")], 0))
#print(memory_cell_ckt.get_output(1, 0, 0))
"""
print(memory_array_ckt.get_outputs(word_generator(15), byte_generator(0x00)))
print(memory_array_ckt.get_outputs(word_generator(32), byte_generator(0x01)))
print(memory_array_ckt.get_outputs(word_generator(15), byte_generator(0x00)))
print(memory_array_ckt.get_outputs(word_generator(7), byte_generator(0x10)))
print(memory_array_ckt.get_outputs(word_generator(3), byte_generator(0x011)))
print(memory_array_ckt.get_outputs(word_generator(15), byte_generator(0x00)))
print(memory_grid_ckt.get_outputs(word_generator(53), word_generator(0x05)[-4:], byte_generator(0x02)))
print(memory_grid_ckt.get_outputs(word_generator(53), word_generator(0x05)[-4:], byte_generator(0x12)))
print(memory_grid_ckt.get_outputs(word_generator(53), word_generator(0x05)[-4:], byte_generator(0x12)))
print(memory_grid_ckt.get_outputs(word_generator(53), word_generator(0x05)[-4:], byte_generator(0x02)))
print(memory_grid_ckt.get_outputs(word_generator(53), word_generator(0x05)[-4:], byte_generator(0x03)))
print(memory_grid_ckt.get_outputs(word_generator(3), word_generator(0x05)[-4:], byte_generator(0x02)))
print(memory_grid_ckt.get_outputs(word_generator(3), word_generator(0x0F)[-4:], byte_generator(0x02)))
"""
count = [0]*14
for i in range(10):
    current_clock_state = clock.get_output()
    print(val := int(list_to_string(count), 2))
    counter.set_initial_state(val)
    count = counter.get_outputs(current_clock_state)
    print(current_clock_state, count)
