import math

from sequential_logic.latches_ffs import *
from imports.gates.allGates import *
from imports.general_imports import *
from imports.combinational_logic.data_manipulative import *
from imports.circuit import *


class MemoryCell(Circuit):
    """
    ____________________________________________________________
    sel_l | read_write_bar |        state
    ------------------------------------------------------------
        0 |             0  | op = hi_z : ip = d_in (store data)
        0 |             1  | op = data : ip = none (retrieve)
        1 |             0  | op = hi_z : ip = none (none)
        1 |             1  | op = hi_z : ip = none (none)
    ------------------------------------------------------------
    """

    def __init__(self):
        super().__init__()
        self.d_ff_ckt = DFF()

    def get_output(self, bit_in, sel_low, read_write_bar):
        d_ff_result = self.d_ff_ckt.get_outputs(bit_in, nor_gate.get_output(
            [sel_low, read_write_bar]))[0]
        return tri_state_cell_ckt.get_output(d_ff_result, not_gate.get_output(nand_gate.get_output(
            [not_gate.get_output(sel_low), read_write_bar])))


class MemoryArray(Circuit):
    def __init__(self, size_in_bits, device_id):
        super().__init__()
        self.size_in_bits = size_in_bits
        self.d_ff_array_ckt = [DFF() for i in range(size_in_bits)]
        self.device_id = device_id

    def get_outputs(self, data_in, device_selection_data):
        sel_low = nand_gate.get_output(
            [
                xnor_gate.get_output([bit1, bit2])
                for bit1, bit2 in zip(device_selection_data[:-1] + [0], self.device_id)
            ]
        )
        read_write_bar = not_gate.get_output(device_selection_data[-1])
        d_ff_result = [d_ff_ckt.get_outputs(data_in[i], nor_gate.get_output(
            [sel_low, read_write_bar]))[0] for i, d_ff_ckt in enumerate(self.d_ff_array_ckt)]
        return tri_state_array_ckt.get_outputs(d_ff_result, not_gate.get_output(nand_gate.get_output(
            [not_gate.get_output(sel_low), read_write_bar])))


class MemoryNxMGrid(Circuit):
    """
    building address selection logic => using 2 128x1 mux
                                     =>   using 1 2x1 mux
    """

    def __init__(self, rows, columns, device_id):
        super().__init__()
        self.size_in_bits = columns
        self.num_words = rows
        self.memory_grid_ckt = [[MemoryCell() for i in range(self.size_in_bits)] for j in range(self.num_words)]
        self.num_address_selection_bits = int(math.log2(self.num_words))
        self.dmux_address_selection_ckt = DMUX1ToN(self.num_address_selection_bits)
        self.data_bus = BUS("memory_grid_bus")
        self.device_id = device_id

    def get_outputs(self, data_in, address, device_selection_data):
        sel_low = nand_gate.get_output(
            [
                xnor_gate.get_output([bit1, bit2])
                for bit1, bit2 in zip(device_selection_data[:-1] + [0], self.device_id)
            ]
        )
        read_write_bar = not_gate.get_output(device_selection_data[-1])
        address_result = self.dmux_address_selection_ckt.get_output(1, address[-self.num_address_selection_bits:])
        mem_result = [[mem_cell.get_output(bit_in, or_gate.get_output([sel_low, not_gate.get_output(address_bit)]),
                                           read_write_bar) for mem_cell, bit_in in zip(mem_array, data_in)]
                      for mem_array, address_bit in zip(self.memory_grid_ckt, address_result)]
        """for i, address_bit in enumerate(address_result):
            if address_bit:
                d_ff_result = d_ff_result[i]
                break
                """

        """
        d_ff_result = []
        for i, address_bit in enumerate(address_result):
            if address_bit:
                d_ff_result = [d_ff_ckt.get_outputs(data_in[j], nor_gate.get_output(
                    [not_gate.get_output(address_bit), read_write_bar]))[0]
                               for j, d_ff_ckt in enumerate(self.d_ff_grid_ckt[i])]
                break
        """
        mem_result = self.data_bus.get_outputs(mem_result)
        return tri_state_array_ckt.get_outputs(mem_result, not_gate.get_output(nand_gate.get_output(
            [not_gate.get_output(sel_low), read_write_bar])))


class MemoryNxMGrid_old(Circuit):
    """
    building address selection logic => using 2 128x1 mux
                                     =>   using 1 2x1 mux
    """

    def __init__(self, rows, columns):
        super().__init__()
        self.size_in_bits = columns
        self.num_words = rows
        self.d_ff_grid_ckt = [[DFF() for i in range(self.size_in_bits)] for j in range(self.num_words)]
        self.dmux_address_selection_ckt = DMUX1ToN(int(math.log2(self.num_words)))
        self.data_bus = BUS(1)

    def get_outputs(self, data_in, sel_low, read_write_bar, address):
        address_result = self.dmux_address_selection_ckt.get_output(1, address)

        d_ff_result = [[d_ff_ckt.get_outputs(data_in[i], nor_gate.get_output(
            [not_gate.get_output(address_result[j]), read_write_bar]))[0] for i, d_ff_ckt in enumerate(d_ff_array_ckt)]
                       for j, d_ff_array_ckt in enumerate(self.d_ff_grid_ckt)]
        print(d_ff_result)
        for i, address_bit in enumerate(address_result):
            if address_bit:
                d_ff_result = d_ff_result[i]
                break

        """
        d_ff_result = []
        for i, address_bit in enumerate(address_result):
            if address_bit:
                d_ff_result = [d_ff_ckt.get_outputs(data_in[j], nor_gate.get_output(
                    [not_gate.get_output(address_bit), read_write_bar]))[0]
                               for j, d_ff_ckt in enumerate(self.d_ff_grid_ckt[i])]
                break
        """
        return tri_state_array_ckt.get_outputs(d_ff_result, not_gate.get_output(nand_gate.get_output(
            [not_gate.get_output(sel_low), read_write_bar])))
