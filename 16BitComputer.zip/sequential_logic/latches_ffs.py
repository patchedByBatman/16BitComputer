from imports.general_imports import *
from imports.gates.allGates import *
from imports.circuit import Circuit


class SRLatchActiveLow(Circuit):
    def __init__(self):
        super().__init__()
        self.q = 1
        self.q_bar = 0
        self.q_prev = 1
        self.q_bar_prev = 0

    def get_outputs(self, s_bar, r_bar):
        # print("sr__L {} {}".format(s_bar, self.q_bar))
        self.q_prev = self.q
        self.q_bar_prev = self.q_bar
        self.q = nand_gate.get_output([s_bar, self.q_bar])
        self.q_bar = nand_gate.get_output([r_bar, self.q])
        self.q = nand_gate.get_output([s_bar, self.q_bar])
        self.q = self.q_prev if self.q is None else self.q
        self.q_bar = self.q_bar_prev if self.q_bar is None else self.q_bar
        return self.q, self.q_bar


class SRGatedLatch(Circuit):
    def __init__(self):
        super().__init__()
        self.sr_latch = SRLatchActiveLow()

    def get_outputs(self, s, r, en):
        s_bar = nand_gate.get_output([s, en])
        # print("sr {} {}".format(r, en))
        r_bar = nand_gate.get_output([r, en])
        return self.sr_latch.get_outputs(s_bar, r_bar)


class JKFF(Circuit):
    def __init__(self):
        super().__init__()
        self.sr_latch = SRLatchActiveLow()

    def get_outputs(self, j, k, en):
        s_bar = nand_gate.get_output([j, en, self.sr_latch.q_bar])
        r_bar = nand_gate.get_output([k, en, self.sr_latch.q])
        return self.sr_latch.get_outputs(s_bar, r_bar)


class DFF(Circuit):
    def __init__(self):
        super().__init__()
        self.sr_gated_latch = SRGatedLatch()

    def get_outputs(self, d, en):
        r = not_gate.get_output(d)
        return self.sr_gated_latch.get_outputs(d, r, en)


class TFF(Circuit):
    def __init__(self):
        super().__init__()
        self.jk_ff = JKFF()

    def get_outputs(self, t, en):
        return self.jk_ff.get_outputs(t, t, en)
